# 2026XXXXXX —— 基于 YOLOv8-n 的机器人场景目标检测

> 2026 年全国大学生计算机系统能力大赛 · 智能系统创新设计赛（小米杯）工程实践项目
> 来源仓库：`SDNURoboticsAILab/2026AutumnEngineeringChallenges` → `YOLO/`

使用 **Ultralytics YOLOv8-n** 检测机器人场景中的三类目标：

| 编号 | 类别名 | 中文 | 说明 |
|---|---|---|---|
| 0 | `obstacle` | 障碍物 | 纸盒等挡路物体 |
| 1 | `cola` | 可乐 | 可乐塑料瓶 |
| 2 | `football` | 足球 | 足球 |

数据集为 **6 张自制图片**，手动划分为 train 4 张 / val 2 张。

---

## 当前完成状态（如实说明）

| 项目 | 状态 |
|---|---|
| 数据集与标注（6 张图 / 6 个标签） | ✅ 已完成，标签为 YOLO 归一化格式 |
| `data.yaml` 配置 | ✅ 已完成，**已通过 Ultralytics 实际解析校验**（nc=3，names 正确，train 4/4、val 2/2 配对成功） |
| `train.py` / `predict.py` 代码 | ✅ 已完成，`train.py --check-only` 自检通过（输出"配对数量: 6"） |
| 环境安装与校验（Windows 11） | ✅ 已完成（ultralytics 8.4.163 / torch 2.10.0+cpu） |
| **完整训练** | ❌ **未完成** —— 本机受 Windows 长路径策略限制，无法完整执行训练 |
| 训练权重 `best.pt` | ❌ 不存在（**不伪造**） |
| 训练结果图 / 推理效果图 | ❌ 不存在（**不伪造**），`runs/` 保持为空 |

> `results/` 目录中以**文档形式**说明了训练完成后会产出什么、日志长什么样
> （`training_log_sample.md`、`inference_sample.md`），这些是**预期结果说明，不是真实产物**。
> 未完成原因与完整排错过程见 `report.md` 第四节。

---

## 目录结构

```text
2026XXXXXX/
├── README.md                      # 本文件：项目总览与快速复现
├── report.md                      # 完整实践报告（环境、数据、原理、代码讲解、Level 记录）
├── train.py                       # YOLOv8-n 训练脚本（含训练前自检）
├── predict.py                     # 加载 best.pt 推理并绘制结果图
├── data.yaml                      # 数据集配置：相对路径 + nc=3 + names
├── requirements.txt               # 完整依赖清单（含安装顺序与镜像说明）
├── dataset/
│   ├── images/
│   │   ├── train/                 # 训练集图片目录（放 img01.jpg ~ img04.jpg，当前为空）
│   │   └── val/                   # 验证集图片目录（放 img05.jpg ~ img06.jpg，当前为空）
│   └── labels/
│       ├── train/                 # img01.txt ~ img04.txt（已完成）
│       └── val/                   # img05.txt ~ img06.txt（已完成）
├── runs/                          # 训练输出目录，初始为空，由 Ultralytics 自动生成
└── results/                       # 结果说明与展示材料目录
    ├── README_results.md          # 训练完成后这里应存放什么
    ├── training_log_sample.md     # 模拟训练输出日志样例（文档形式）
    ├── inference_sample.md        # 推理结果样例（文档形式）
    └── image_filelist.md          # 6 张图片的文件名清单与标注说明
```

### 关键约定

- `dataset/images/` 下**不含图片文件**（仓库体积考虑），请把 6 张原图按
  `results/image_filelist.md` 规定的文件名放入；标签已写好并与图片**严格同名、仅后缀不同**。
- `runs/` 是**程序自动产物目录**，初始为空是正常的，不要手工往里面放文件。
- 所有代码与配置**只使用相对路径**，不含 `C:/` `D:/` 之类绝对路径，可整体拷贝到 Linux / Colab。

---

## 快速复现

### 1. 安装依赖

```bash
python -m venv .venv
.venv\Scripts\activate            # Windows
# source .venv/bin/activate       # Linux / macOS / Colab

python -m pip install --upgrade pip
pip install -r requirements.txt

# 国内网络慢时：
# pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

# 需要 GPU 训练时，先按自己的 CUDA 版本装 GPU 版 torch，再装 ultralytics：
# pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
```

验证环境：

```bash
python -c "import ultralytics, torch; print(ultralytics.__version__, torch.__version__, torch.cuda.is_available())"
```

### 2. 放入图片

按 `results/image_filelist.md` 把 6 张原图放入：
`dataset/images/train/img01.jpg` ~ `img04.jpg`、`dataset/images/val/img05.jpg` ~ `img06.jpg`

### 3. 训练前自检（强烈建议）

```bash
python train.py --check-only
```

预期结尾输出：

```text
[OK] 有效的 图片/标签 配对数量: 6
```

若此处报错，请先按提示修复，不要直接开始训练（训练很耗时，低级错误代价高）。

### 4. 开始训练

```bash
# 标准配置（有 GPU）
python train.py --epochs 100 --imgsz 640 --batch 4 --device 0

# 仅有 CPU 时先用小规模跑通流程
python train.py --epochs 30 --imgsz 320 --batch 2 --device cpu
```

训练产物自动写入 `runs/detect/train/`，其中 `weights/best.pt` 是后续推理要用的权重。

### 5. 检测新图片

```bash
python predict.py --source new_photos --conf 0.25 --print-dets
```

结果图（含**目标框 + 类别名称 + 置信度**）保存在 `runs/detect/predict/`。

### 6. Colab 一键复现

```python
!nvidia-smi                                    # 确认 GPU（无则改运行时为 T4 GPU）
!pip install -q ultralytics                    # Colab 已自带 CUDA 版 torch
%cd /content/2026XXXXXX                        # 项目放到纯英文短路径
!python train.py --check-only
!python train.py --epochs 150 --imgsz 640 --batch 8 --device 0
!python predict.py --source new_photos --conf 0.25 --print-dets
```

完整步骤（含上传方式、结果保存、网页演示）见 `report.md` 第九节。

---

## 常见问题速查

| 现象 | 原因与处理 |
|---|---|
| 训练报 `images not found` | `data.yaml` 里不要写 `path:` 键；保留相对路径 `dataset/images/train` |
| `配对数量: 0` | 图片没放进去，或图片名与 labels 下的 `.txt` 不一致 |
| 中文在终端显示为乱码 | 只是控制台编码问题：`chcp 65001` 后重试，不影响功能 |
| 报 `PermissionError` / 路径异常 | Windows 长路径问题，把项目移到纯英文短路径（如 `D:\yolo\`） |
| `predict.py` 报找不到 `best.pt` | 尚未训练成功；该脚本要求使用自己训练的权重，不会自动下载预训练权重 |
| 结果图上的类别是 `person`/`bottle` | 加载成了官方 COCO 权重，请确认路径指向 `runs/detect/train/weights/best.pt` |

---

## 参考资源

- [Ultralytics YOLO 官方文档](https://docs.ultralytics.com/)
- [Ultralytics 数据集格式说明](https://docs.ultralytics.com/datasets/)
- [Ultralytics Train / Predict Mode](https://docs.ultralytics.com/modes/train/)
- [YOLO 性能指标说明（Precision / Recall / mAP）](https://docs.ultralytics.com/guides/yolo-performance-metrics/)
- [Make-Sense 标注工具](https://github.com/SkalskiP/make-sense)
- [PyTorch 安装指引](https://pytorch.org/get-started/locally/)
