#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
train.py —— 使用 Ultralytics YOLOv8-n 训练 obstacle / cola / football 三分类检测模型
================================================================================
项目位置: 2026XXXXXX/train.py

【功能】
把 data.yaml 指定的自制数据集（train 4 张 / val 2 张）喂给 YOLOv8-n 做迁移学习，
产出一个能识别三类目标的权重文件 best.pt。

【运行方式】（在本文件所在目录下执行）
    python train.py                                  # 使用下方默认超参
    python train.py --epochs 150 --imgsz 640 --batch 4
    python train.py --device 0                        # 有 NVIDIA GPU 时
    python train.py --check-only                      # 只做训练前自检，不训练

【训练产物】（由 Ultralytics 自动生成到 runs/detect/<name>/ 下）
    runs/detect/train/weights/best.pt   验证集上表现最好的权重（推理用这个）
    runs/detect/train/weights/last.pt   最后一轮权重（断点续训用）
    runs/detect/train/args.yaml         本次训练的全部超参（实验记录）
    runs/detect/train/results.csv       每轮 loss / precision / recall / mAP
    runs/detect/train/results.png       上述指标随轮数变化的曲线
    runs/detect/train/confusion_matrix.png
    runs/detect/train/val_batch0_pred.jpg   验证集预测可视化

【路径规范】本脚本只使用【相对路径】与基于 __file__ 的动态路径，
           不含任何 C:/ D:/ 之类的绝对路径，可直接拷贝到 Colab / Linux 运行。
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# 0. 路径常量（全部基于本文件位置动态推导，因此是"相对"的、可移植的）
# ---------------------------------------------------------------------------
# Path(__file__).resolve().parent 即本脚本所在目录（2026XXXXXX/）。
# 这样无论你从哪个工作目录执行 python train.py，都能正确定位 data.yaml，
# 并把 runs/ 稳定输出到项目根目录下。
PROJECT_ROOT = Path(__file__).resolve().parent
DATA_YAML = PROJECT_ROOT / "data.yaml"

# 支持识别的图片后缀
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}


def parse_args() -> argparse.Namespace:
    """解析命令行参数：把常用超参暴露出来，方便调参与做对比实验（不改代码）。"""
    p = argparse.ArgumentParser(
        description="在自制三分类数据集上训练 YOLOv8-n 目标检测模型",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # ======================= 模型与数据 =======================
    # yolov8n.pt：YOLOv8 nano 的官方预训练权重（约 3.2M 参数 / 6MB）。
    #   首次运行 Ultralytics 会自动从 GitHub 下载该权重并缓存到本地。
    #   使用预训练权重做迁移学习（而不是从随机初始化开始）是本项目能跑通的关键：
    #   只有 6 张图，从零训练完全学不到东西；COCO 上学到的通用视觉特征可以迁移复用。
    p.add_argument("--model", default="yolov8n.pt",
                   help="模型权重。yolov8n.pt 即 YOLOv8-n；也可换成 yolov8s.pt 等")
    # 数据集配置。默认指向本目录下的 data.yaml（相对路径，可移植）
    p.add_argument("--data", default=str(DATA_YAML), help="数据集配置文件路径")

    # ======================= 训练规模 =======================
    # epochs：训练轮数。整个训练集被完整学习一遍称为 1 个 epoch。
    #   样本量极小（4 张），轮数太少模型根本来不及收敛，故给 100~300。
    p.add_argument("--epochs", type=int, default=100, help="训练总轮数")
    # batch：一次前向/反向传播同时处理几张图。
    #   4 张训练图配 batch=4，可让每个 batch 内出现多个目标（img01/img02 各含 3 个框）。
    p.add_argument("--batch", type=int, default=4, help="批大小；-1 表示自动估计")

    # ======================= 输入尺寸 =======================
    # imgsz：训练前把图片统一缩放到 imgsz × imgsz 的正方形送入网络。
    #   640 是 YOLOv8 官方默认值，也是精度与速度的平衡点。
    #   内存/显存不足时降到 416 或 320；纯 CPU 冒烟测试建议 320。
    p.add_argument("--imgsz", type=int, default=640, help="网络输入边长（正方形）")

    # ======================= 设备与数据加载 =======================
    # workers：DataLoader 读图子进程数。
    #   Windows 上子进程通过 spawn 重新导入主模块，在复杂环境下易卡死或报错，
    #   因此 Windows 默认取 0（主进程读图，慢但稳定）；Linux / Colab 取 8 加速。
    p.add_argument("--workers", type=int, default=0 if os.name == "nt" else 8,
                   help="数据加载子进程数（Windows 建议 0）")
    # device："" 表示自动选择（有 GPU 用 GPU）；"cpu" 强制 CPU；"0" 用第 0 号 GPU。
    p.add_argument("--device", default="", help="cpu / 0 / 0,1；留空为自动")

    # ======================= 优化器超参 =======================
    # lr0：初始学习率。0.01 是 YOLOv8 配 SGD 的默认值。
    #   微调小数据集时可适当调小（如 0.001），避免一步把预训练权重"冲坏"。
    # lrf：最终学习率 = lr0 × lrf，配合余弦退火让训练后期步长变小、收敛更稳。
    # momentum：SGD 动量，利用历史梯度平滑更新方向。
    # weight_decay：权重衰减（L2 正则），抑制权重过大以缓解过拟合。
    p.add_argument("--lr0", type=float, default=0.01, help="初始学习率")
    p.add_argument("--lrf", type=float, default=0.01, help="最终学习率系数 lr_final = lr0*lrf")
    p.add_argument("--momentum", type=float, default=0.937, help="SGD 动量")
    p.add_argument("--weight-decay", type=float, default=0.0005, help="权重衰减系数")
    p.add_argument("--optimizer", default="auto", help="优化器: auto/SGD/Adam/AdamW")
    # patience：早停。连续 N 轮验证指标不再提升就提前结束，避免无意义训练。
    p.add_argument("--patience", type=int, default=50, help="早停耐心值")

    # ======================= 数据增强 =======================
    # 只有 6 张图，必须依赖数据增强"人造"出更多变化，否则必然严重过拟合。
    # fliplr：左右翻转概率。可乐瓶、足球左右翻转后语义不变，属安全增强。
    #   （若目标是文字/数字，翻转会改变语义，不能开启。）
    # mosaic：把 4 张图随机拼成 1 张，让模型见到更多背景与尺度组合。
    # hsv_h/s/v：随机调整色调/饱和度/亮度，模拟不同光照条件。
    # scale/translate：随机缩放与平移，提升对目标大小与位置变化的鲁棒性。
    # degrees：随机旋转角度，本项目目标摆放较正，故设为 0。
    p.add_argument("--fliplr", type=float, default=0.5, help="左右翻转概率")
    p.add_argument("--flipud", type=float, default=0.0, help="上下翻转概率（本项目关闭）")
    p.add_argument("--mosaic", type=float, default=1.0, help="mosaic 四图拼接概率")
    p.add_argument("--hsv-h", type=float, default=0.015, help="HSV 色调抖动幅度")
    p.add_argument("--hsv-s", type=float, default=0.7, help="HSV 饱和度抖动幅度")
    p.add_argument("--hsv-v", type=float, default=0.4, help="HSV 明度抖动幅度")
    p.add_argument("--degrees", type=float, default=0.0, help="随机旋转角度范围（关闭）")
    p.add_argument("--scale", type=float, default=0.5, help="随机缩放增益范围")
    p.add_argument("--translate", type=float, default=0.1, help="随机平移比例")
    # close_mosaic：最后 N 轮关闭 mosaic。mosaic 生成的图与真实图分布有差异，
    #   训练末尾关掉它可让模型在真实分布上做最后收敛，通常能提升最终精度。
    p.add_argument("--close-mosaic", type=int, default=10, help="最后 N 轮关闭 mosaic")

    # ======================= 输出与可复现性 =======================
    # 输出目录 = project / name，即 runs/detect/train。
    #   重复运行时会自动变成 train2、train3……除非指定 --exist-ok。
    p.add_argument("--project", default=str(PROJECT_ROOT / "runs" / "detect"),
                   help="训练输出根目录（相对项目根目录推导）")
    p.add_argument("--name", default="train", help="本次实验的子目录名")
    p.add_argument("--exist-ok", action="store_true", help="允许覆盖同名输出目录")
    # seed：随机种子。固定后数据顺序、增强随机数、权重初始化均可复现，
    #   报告中给出的指标才有对比意义（否则每次跑出的 mAP 都不同）。
    p.add_argument("--seed", type=int, default=42, help="随机种子（保证结果可复现）")
    p.add_argument("--deterministic", action="store_true", default=True,
                   help="启用确定性算法（配合 seed 使用）")
    p.add_argument("--resume", action="store_true", help="从 last.pt 断点续训")

    # ======================= 验证与绘图 =======================
    # val=True：每个 epoch 结束后都在验证集上评估一次，并据此选出 best.pt。
    #   验证集不参与梯度更新，因此其指标才能反映模型的泛化能力。
    p.add_argument("--val", action="store_true", default=True, help="每轮在 val 上验证")
    p.add_argument("--plots", action="store_true", default=True, help="生成结果曲线图")

    # ======================= 仅自检 =======================
    p.add_argument("--check-only", action="store_true",
                   help="只检查环境与数据集，不真正开始训练（用于快速排错）")
    return p.parse_args()


def check_env_and_dataset(args: argparse.Namespace) -> int:
    """训练前自检：把最常见的失败原因提前暴露，而不是等 YOLO 抛栈。

    检查项：
      1) ultralytics 是否可导入及其版本；
      2) torch 是否可用、CUDA 是否可用（决定训练速度预期）；
      3) data.yaml 是否存在、能否以 UTF-8 解析、nc 与 names 是否一致；
      4) images/train、images/val 目录是否存在；
      5) 每张图片是否有同名 .txt 标签（图片与标签必须一一对应）。

    返回值：成功配对的 图片/标签 数量。
    """
    print("=" * 74)
    print(" 训练前自检 (pre-flight check)")
    print("=" * 74)

    # ---------- 1) ultralytics ----------
    try:
        import ultralytics
    except ImportError:
        print("[X] 未安装 ultralytics，请先执行: pip install -r requirements.txt")
        return 0
    print(f"[OK] ultralytics 版本 : {ultralytics.__version__}")

    # ---------- 2) torch / CUDA ----------
    try:
        import torch
        cuda = torch.cuda.is_available()
        print(f"[OK] torch 版本       : {torch.__version__}")
        print(f"[OK] CUDA 可用        : {cuda}")
        if not cuda:
            # 这不是错误，只是性能预期提示：CPU 上完整训练会非常慢。
            print("     [!] 未检测到可用 GPU，将回退到 CPU 训练。")
            print("         建议先用小规模跑通流程: --epochs 30 --imgsz 320 --batch 2")
            print("         正式训练建议放到 Colab / Linux 的 GPU 环境（见 README 复现指南）。")
    except ImportError:
        print("[!] 未安装 torch，无法检查 CUDA（ultralytics 会自动安装它）")

    # ---------- 3) data.yaml ----------
    data_path = Path(args.data)
    if not data_path.is_file():
        print(f"[X] 找不到数据集配置文件: {data_path}")
        return 0
    print(f"[OK] data.yaml        : {data_path}")

    try:
        import yaml
        # 显式用 UTF-8 读取：Windows 默认 ANSI(GBK) 解码含中文的 yaml 会直接抛异常
        with open(data_path, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
    except Exception as e:
        print(f"[X] data.yaml 解析失败: {e!r}")
        print("    常见原因：文件被存成 GBK 编码，或缩进混用了 Tab。请另存为 UTF-8。")
        return 0

    names = cfg.get("names", {})
    nc = cfg.get("nc", None)
    if isinstance(names, list):
        names = {i: n for i, n in enumerate(names)}
    print(f"[OK] nc               : {nc}")
    print(f"[OK] names            : {names}")

    # nc 与 names 数量必须一致，这是最常见且最难定位的配置错误之一
    if nc is not None and len(names) != nc:
        print(f"[X] nc={nc} 但 names 有 {len(names)} 项，二者必须相等！")
        return 0
    if not {0, 1, 2}.issubset(set(names.keys())):
        print("[X] names 缺少 0/1/2 中的某个类别编号，请检查 data.yaml。")
        return 0

    # ---------- 4) + 5) 图片目录与标签配对 ----------
    # 目录按 data.yaml 所在目录解析，与 Ultralytics 的行为保持一致。
    data_root = data_path.resolve().parent
    total_pairs = 0

    for split in ("train", "val"):
        rel = cfg.get(split)
        if rel is None:
            print(f"[X] data.yaml 中缺少 '{split}:' 配置项")
            return 0
        img_dir = (data_root / rel).resolve()
        # YOLO 约定：把 /images/ 换成 /labels/ 即标签目录
        lbl_dir = Path(str(img_dir).replace(
            os.sep + "images" + os.sep, os.sep + "labels" + os.sep))

        if not img_dir.is_dir():
            print(f"[X] {split} 图片目录不存在: {img_dir}")
            return 0

        images = sorted(p for p in img_dir.iterdir() if p.suffix.lower() in IMAGE_EXTS)
        print(f"[OK] {split:5s} 图片目录 : {img_dir}  （{len(images)} 张）")

        if not images:
            print(f"     [!] {split} 目录为空。请把原图按 FILELIST.txt 规定的文件名放入，")
            print("         文件名需与 labels 下的 .txt 完全一致（仅后缀不同）。")

        # 逐张检查是否有同名标签
        missing = []
        for img in images:
            if (lbl_dir / f"{img.stem}.txt").is_file():
                total_pairs += 1
            else:
                missing.append(img.stem + ".txt")
        if missing:
            # 缺标签的图片会被 YOLO 当作"背景图"（负样本）处理。
            # 少量可接受，数量多则说明标注/命名有问题，必须明确警告。
            print(f"     [!] {len(missing)} 张图缺少同名标签: {missing[:5]}"
                  f"{' ...' if len(missing) > 5 else ''}")

    print(f"[OK] 有效的 图片/标签 配对数量: {total_pairs}")
    print("=" * 74)
    return total_pairs


def main() -> None:
    args = parse_args()

    # 切换到项目根目录：保证 runs/ 输出位置、预训练权重下载位置可预期。
    # data.yaml 使用相对路径，以 yaml 自身所在目录为根解析，
    # 因此切不切目录都不影响数据解析，这里切换只为让输出目录稳定。
    os.chdir(PROJECT_ROOT)

    pairs = check_env_and_dataset(args)

    if args.check_only:
        print("--check-only 已指定：自检完成，退出（不进行训练）。")
        return

    if pairs == 0:
        print("[X] 没有任何有效的 图片/标签 配对，训练必然失败。")
        print("    请先把 6 张原图按 dataset/FILELIST.txt 中的文件名放入 images/ 目录。")
        sys.exit(1)

    # 自检通过后才导入 YOLO：这样缺依赖时能给出中文提示而不是一长串报错栈
    from ultralytics import YOLO

    # =======================================================================
    # 1. 加载模型（迁移学习：加载 COCO 预训练权重）
    # =======================================================================
    # YOLO("yolov8n.pt") 会读取官方预训练权重：
    #   - backbone / neck 直接继承 COCO 上学到的通用特征提取能力；
    #   - head 的输出通道在首次读取 data.yaml 时自动由 80 类改为 3 类（nc=3）。
    # 若写成 yolov8n.yaml 则是从随机初始化开始训练（本项目不推荐）。
    print(f"[1/3] 加载模型: {args.model}")
    model = YOLO(args.model)

    # =======================================================================
    # 2. 开始训练
    # =======================================================================
    # 传入的所有参数会被 Ultralytics 完整记录进 runs/detect/<name>/args.yaml，
    # 便于日后精确复现本次实验。
    print(f"[2/3] 开始训练: epochs={args.epochs}, imgsz={args.imgsz}, batch={args.batch}")
    results = model.train(
        # ---- 数据与训练规模 ----
        data=args.data,           # 数据集配置（图片/标签位置、nc、names）
        epochs=args.epochs,       # 训练轮数
        batch=args.batch,         # 批大小
        imgsz=args.imgsz,         # 输入分辨率（正方形边长）
        # ---- 设备与数据加载 ----
        device=args.device or None,  # None = 自动选择设备
        workers=args.workers,        # 读图子进程数
        # ---- 优化器 ----
        optimizer=args.optimizer,
        lr0=args.lr0,                # 初始学习率
        lrf=args.lrf,                # 最终学习率系数
        momentum=args.momentum,      # SGD 动量
        weight_decay=args.weight_decay,
        # warmup：前若干轮用很小的学习率热身，避免初期大梯度破坏预训练权重
        warmup_epochs=3.0,
        patience=args.patience,      # 早停耐心值
        # ---- 数据增强（小样本必备）----
        hsv_h=args.hsv_h,
        hsv_s=args.hsv_s,
        hsv_v=args.hsv_v,
        degrees=args.degrees,
        translate=args.translate,
        scale=args.scale,
        fliplr=args.fliplr,
        flipud=args.flipud,
        mosaic=args.mosaic,
        close_mosaic=args.close_mosaic,
        # ---- 输出与可复现性 ----
        project=args.project,        # 输出根目录
        name=args.name,              # 本次实验子目录名
        exist_ok=args.exist_ok,      # 是否允许覆盖同名目录
        seed=args.seed,              # 随机种子
        deterministic=args.deterministic,
        resume=args.resume,          # 断点续训
        # ---- 验证与可视化 ----
        val=args.val,                # 每轮在验证集上评估
        plots=args.plots,            # 生成 results.png / 混淆矩阵等
        # ---- 缓存 ----
        # 数据集很小，cache=True 把图片一次性读入内存，省去每轮的磁盘 IO。
        cache=True,
    )

    # =======================================================================
    # 3. 输出结果位置
    # =======================================================================
    save_dir = Path(getattr(results, "save_dir",
                            PROJECT_ROOT / "runs" / "detect" / args.name))
    best = save_dir / "weights" / "best.pt"
    print(f"\n[3/3] 训练结束，输出目录: {save_dir}")
    print(f"      最佳权重: {best}  （存在: {best.is_file()}）")
    print("      下一步：")
    print("        python predict.py --source <待检测图片或目录>")
    print("      或按 results/README_results.md 的说明整理训练结果材料。")


if __name__ == "__main__":
    # Windows 上当 workers>0 时，DataLoader 子进程会重新导入本模块，
    # 必须依赖这个 __main__ 守卫，否则会无限递归创建进程。
    main()
