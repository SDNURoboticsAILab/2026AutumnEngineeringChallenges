# YOLOv8 机器人场景目标检测 —— 项目实践报告

| 项目 | 内容 |
|---|---|
| 提交目录 | `2026XXXXXX/`（学号目录，提交前替换为真实学号） |
| 任务来源 | `SDNURoboticsAILab/2026AutumnEngineeringChallenges` → `YOLO/` |
| 检测类别 | `0: obstacle`、`1: cola`、`2: football` |
| 模型 | Ultralytics **YOLOv8-n**（`yolov8n.pt` 迁移学习） |
| 数据集 | 6 张自制图片，train 4 张（img01~img04）/ val 2 张（img05~img06） |
| 标注工具 | Make-Sense（导出 bug 后手工补全并逐行核对） |
| 开发环境 | Windows 11 + Python 3.12.10 + torch 2.10.0+cpu + ultralytics 8.4.163 |
| 完成情况 | Level 1~2 完成；Level 3 代码与配置就绪、本机受长路径限制未完整训练；Level 4~5 代码就绪 |

---

## 目录

1. [项目概述与目录结构](#一项目概述与目录结构)
2. [环境准备与安装尝试过程](#二环境准备与安装尝试过程)
3. [数据集构建、来源与标注流程](#三数据集构建来源与标注流程)
4. [Windows 长路径问题与排查记录](#四windows-长路径问题与排查记录)
5. [训练集 / 验证集划分理由](#五训练集--验证集划分理由)
6. [YOLOv8 原理简述](#六yolov8-原理简述)
7. [代码与配置逐部分讲解](#七代码与配置逐部分讲解)
8. [预期训练结果与 loss 变化](#八预期训练结果与-loss-变化)
9. [预期推理效果与指标水平](#九预期推理效果与指标水平)
10. [各 Level 完成记录与截图证据清单](#十各-level-完成记录与截图证据清单)
11. [Colab 复现指南](#十一colab-复现指南)
12. [总结与不足](#十二总结与不足)

---

## 一、项目概述与目录结构

### 1.1 项目目标

围绕实验室机器人场景，使用提供的 `obstacle`（障碍物）、`cola`（可乐）、`football`（足球）
三类目标，完整走一遍目标检测工程流程：
**数据整理 → 目标标注 → 数据集划分 → 模型训练 → 新图片推理 → 可视化演示**。

项目重点不在于从零实现 YOLO 算法，而在于掌握如何用成熟开源工具完成一个完整的计算机视觉工程实践。

### 1.2 提交目录结构

```text
2026XXXXXX/
├── README.md                      # 项目总览与快速复现命令
├── report.md                      # 本文件：完整实践报告
├── train.py                       # YOLOv8-n 训练脚本
├── predict.py                     # 加载 best.pt 推理并绘制结果图
├── data.yaml                      # 数据集配置（路径、nc、names）
├── requirements.txt               # 依赖清单
├── dataset/
│   ├── images/
│   │   ├── train/                 # img01.jpg ~ img04.jpg（原图需手动放入）
│   │   └── val/                   # img05.jpg ~ img06.jpg（原图需手动放入）
│   └── labels/
│       ├── train/                 # img01.txt ~ img04.txt（已完成）
│       └── val/                   # img05.txt ~ img06.txt（已完成）
├── runs/                          # 初始为空，训练后 Ultralytics 自动生成
└── results/
    ├── README_results.md          # 训练完成后这里应存放什么
    ├── training_log_sample.md     # 模拟训练输出日志样例（文档）
    ├── inference_sample.md        # 推理结果样例（文档）
    └── image_filelist.md          # 6 张图片文件名清单与标注说明
```

### 1.3 关于 `runs/` 目录

`runs/` **初始为空，这是正常状态**。它是 Ultralytics 训练/推理时自动创建并写入的输出目录：

```text
runs/
└── detect/
    └── train/                     # 实验名（train.py 的 --name 参数）
        ├── weights/
        │   ├── best.pt             # ★ 验证集最优权重，predict.py 使用它
        │   └── last.pt             # 最后一轮权重（断点续训）
        ├── args.yaml               # 本次训练的全部超参
        ├── results.csv             # 每轮 loss / P / R / mAP
        ├── results.png             # 指标曲线图
        ├── confusion_matrix.png    # 混淆矩阵
        ├── BoxPR_curve.png 等      # PR / P / R / F1 曲线
        └── val_batch0_pred.jpg     # 验证集预测可视化
```

`runs/` 是**产物目录**而非源码目录，因此本仓库中它保持为空，
**不包含任何伪造的权重或训练日志**。

---

## 二、环境准备与安装尝试过程

### 2.1 开发机配置

| 项目 | 值 |
|---|---|
| 操作系统 | Windows 11（10.0.26200） |
| 处理器 | AMD64 Family 25 Model 117 |
| 独立显卡 | 无 NVIDIA 独显 |
| Python | 3.12.10 |
| 虚拟环境 | 项目内 `.venv` |

### 2.2 安装步骤与遇到的问题

安装顺序如下（这也是踩坑后总结出的正确顺序）：

```bash
# 1) 建立独立虚拟环境，避免污染系统 Python
python -m venv .venv
.venv\Scripts\activate

# 2) 升级 pip —— 关键一步
python -m pip install --upgrade pip

# 3) 先单独安装 torch / torchvision（本机无 GPU，装 CPU 版）
pip install torch torchvision

# 4) 最后安装 ultralytics，让它复用已装好的 torch
pip install ultralytics
```

**遇到的问题 1：依赖版本反复回退、卸载重装**

第一次直接执行 `pip install ultralytics` 时，日志中出现大量
`Attempting uninstall: xxx` / `Successfully uninstalled xxx` 的来回卸载记录，
`torch`、`numpy`、`opencv-python`、`pillow` 等包被反复替换，过程冗长且一度失败。

原因分析：

1. 旧版本 pip 使用的是回溯式依赖解析器，遇到 `ultralytics` 这类依赖树很深的包，
   容易选出一组互相冲突的版本，然后不断回退重试；
2. 系统 Python 中已装有其他项目使用的包，与项目需求冲突；
3. 国内网络访问 PyPI 不稳定，`torch` 的 wheel 有几百 MB，下载中断会导致装出**残缺的包**。

处理方式与效果：

| 措施 | 效果 |
|---|---|
| `python -m pip install --upgrade pip` | 新版解析器一次性算好兼容版本，不再来回卸载 |
| 使用项目独立的 `.venv` | 与系统环境隔离，冲突显著减少 |
| 改用清华镜像源 `-i https://pypi.tuna.tsinghua.edu.cn/simple` | 下载不再中断，包完整 |
| 先装 torch 再装 ultralytics | 避免 ultralytics 自行挑选不合适的 torch 版本 |
| 用最小命令验证 `import` | 确认装成功后再继续 |

**遇到的问题 2：无 CUDA，只能 CPU 训练**

环境探测结果：

```text
torch       : 2.10.0+cpu
torchvision : 0.25.0+cpu
cuda available : False
device count   : 0
```

本机为 AMD 平台且无 NVIDIA 独显，而 PyTorch 的 CUDA 支持只针对 NVIDIA 显卡，
因此 `torch.cuda.is_available()` 返回 `False`，训练只能回退到 CPU。

### 2.3 最终安装成功的环境版本

| 组件 | 版本 |
|---|---|
| Python | 3.12.10 |
| ultralytics | 8.4.163 |
| torch | 2.10.0+cpu |
| torchvision | 0.25.0+cpu |
| opencv-python (`cv2`) | 5.0.0 |
| pillow | 12.3.0 |
| numpy | 2.5.3 |
| PyYAML | 6.0.3 |
| matplotlib | 3.11.2 |
| polars | 1.44.2 |
| psutil | 7.2.2 |

验证命令与结果：

```bash
python -c "import ultralytics, torch; print(ultralytics.__version__, torch.__version__, torch.cuda.is_available())"
# 输出: 8.4.163 2.10.0+cpu False
```

### 2.4 环境校验的实际结论

环境**可以完整安装并通过校验**：依赖齐全、`import` 正常、
`data.yaml` 能被 Ultralytics 正确解析、`train.py --check-only` 自检通过。
卡点不在环境依赖，而在下一节的**系统长路径策略**。

---

## 三、数据集构建、来源与标注流程

### 3.1 图片来源与内容设计

共使用 **6 张自制图片**，用手机在不同角度、不同距离下拍摄三类目标：

| 编号 | 划分 | 内容 | 目标数 | 设计意图 |
|---|---|---|---|---|
| img01 | train | 三类目标同框的全景图 | 3 | 学习多目标共存场景 |
| img02 | train | 大障碍物近景 + 边缘的小可乐/小足球 | 3 | 学习"大目标 + 小目标"的尺度差异 |
| img03 | train | 仅可乐的单目标特写 | 1 | 专注学习可乐的瓶身形状与颜色 |
| img04 | train | 仅足球的单目标特写 | 1 | 专注学习足球的黑白块状纹理 |
| img05 | val | 障碍物与可乐左右并排 | 2 | 验证两个类别能否同时检出 |
| img06 | val | 足球与可乐并排、更换拍摄角度 | 2 | 验证不同位置与视角下的泛化能力 |

图片文件命名统一为 `img01.jpg` ~ `img06.jpg`，
对应的标签文件为 `img01.txt` ~ `img06.txt`（**同名，仅后缀不同**）。
完整的文件名清单与每张图说明见 `results/image_filelist.md`。

> **图片文件未提交进仓库**（控制仓库体积），需要手动把原图按上述文件名放入
> `dataset/images/train/` 与 `dataset/images/val/`。标签文件已全部写好并提交。

### 3.2 标注工具与操作流程

使用网页版 **Make-Sense** 标注（免安装，浏览器中拖拽画框即可，适合 6 张图的小规模标注）。

操作步骤：

1. 打开 Make-Sense，把 6 张图片一次性拖入页面；
2. 在左侧 `Labels` 面板新建三个标签：`obstacle`、`cola`、`football`；
3. 逐张图片拖拽画出**紧贴目标轮廓**的矩形框，并赋予对应标签；
4. 右上角 `Actions → Export Annotations`，格式选择 **YOLO**；
5. 解压导出的 zip，得到与图片同名的 `.txt` 标签文件。

**画框质量要求**：框要尽量紧贴目标边缘。
框过大会把背景像素学成目标特征；框过小会切掉目标的一部分，导致特征学不完整。
两者都会直接影响最终的检测精度。

### 3.3 Make-Sense 导出 bug：zip 里标签为空

#### 现象

从 Make-Sense 导出 YOLO 格式的 zip 并解压后发现：

- 压缩包里**确实存在与图片同名的 `.txt` 文件**，文件名完全正确；
- 但打开后**内容是空白的**，文件大小为 0 字节；
- 把原图重新导入 Make-Sense，**之前画的框仍然存在**——
  说明标注数据没有丢，问题出在**导出环节**。

#### 排查过程

| 步骤 | 操作 | 观察结果 | 结论 |
|---|---|---|---|
| 1 | 重新导入图片检查标注是否存在 | 框都正常显示 | 排除"没画框"的可能 |
| 2 | 检查导出时的格式选项 | 确认选择的是 YOLO，非 CSV/VOC | 排除格式选错 |
| 3 | 重新导出一次并解压 | 现象完全一致 | 排除偶发失败 |
| 4 | 查看 zip 内部文件结构 | 标签文件存在但为 0 字节 | 定位到"导出内容为空" |
| 5 | 更换浏览器重试 | 现象一致 | 排除浏览器差异 |

#### 结论

这是 Make-Sense 导出 YOLO 格式时的一个 bug：
**`labels` 目录中的文件名被正确生成，但标注内容没有被写进去**（写成了 0 字节文件）。

#### 手动修复过程

由于文件名是对的、只有内容缺失，处理思路是**按 YOLO 归一化格式手工补全内容**：

1. 在 Make-Sense 界面上逐张读出每个框的**左上角** `(x_min, y_min)` 与
   **右下角** `(x_max, y_max)` 像素坐标，以及对应的类别；
2. 按公式把像素坐标换算成 0~1 的归一化中心点坐标与宽高；
3. 每个目标写一行，格式为 `类别编号 x_center y_center width height`；
4. 用文本编辑器保存为与图片同名的 `.txt`，**编码必须是 UTF-8**（不能存成 GBK/ANSI）；
5. **逐个文件重新打开核对**：行数是否等于目标数、坐标是否都在 0~1 之间、
   类别编号是否正确。

换算公式（像素 → 归一化）：

```text
x_center = (x_min + x_max) / 2 / 图片宽度
y_center = (y_min + y_max) / 2 / 图片高度
width    = (x_max - x_min)     / 图片宽度
height   = (y_max - y_min)     / 图片高度
```

换算示例（`img03.jpg` 中的可乐，按 640×480 计算）：

```text
像素框: 左上 (215, 145)，右下 (365, 375)

x_center = (215 + 365) / 2 / 640 = 290 / 640 = 0.453
y_center = (145 + 375) / 2 / 480 = 260 / 480 = 0.542
width    = (365 - 215)     / 640 = 150 / 640 = 0.234
height   = (375 - 145)     / 480 = 230 / 480 = 0.479

→ 写入 img03.txt 的内容：
1 0.453000 0.542000 0.234000 0.479000
```

#### 经验教训

**标注完成后第一件事应该是打开标签文件确认内容**，而不是直接拿去训练。
空标签文件在 YOLO 中会被当作"这张图没有目标"（负样本）处理，
训练过程**不会报任何错误**，只会得到一堆无意义的 0 指标，排查起来极其耗时。

### 3.4 YOLO 标签格式说明

每个 `.txt` 文件一行代表一个目标：

```text
<class_id> <x_center> <y_center> <width> <height>
```

| 字段 | 含义 | 取值范围 |
|---|---|---|
| `class_id` | 类别编号（整数） | 0 / 1 / 2 |
| `x_center` | 框**中心点** x 坐标 ÷ 图片宽度 | 0 ~ 1 |
| `y_center` | 框**中心点** y 坐标 ÷ 图片高度 | 0 ~ 1 |
| `width` | 框宽度 ÷ 图片宽度 | 0 ~ 1 |
| `height` | 框高度 ÷ 图片高度 | 0 ~ 1 |

**最容易犯的三个错误**：

| ❌ 错误写法 | ✅ 正确写法 |
|---|---|
| 写像素值 `1 290 260 150 230` | 必须除以宽高归一化为 0~1 小数 |
| 写左上角坐标 `x_min y_min` | 第三、四项是**中心点**坐标 |
| 第三、四项写 `x_max y_max` | 第三、四项是**宽和高** |

若坐标未归一化，YOLO 会报警告并丢弃这些框，表现为"一张图都读不到"。

### 3.5 六个标签文件的完整内容

`dataset/labels/train/img01.txt`（obstacle + cola + football，3 个目标）：

```text
0 0.341406 0.624000 0.220312 0.484000
1 0.267000 0.642000 0.219000 0.333000
2 0.234000 0.729000 0.202000 0.408000
```

`dataset/labels/train/img02.txt`（大 obstacle + cola + football，3 个目标）：

```text
0 0.783000 0.471000 0.344000 0.704000
1 0.289000 0.617000 0.172000 0.350000
2 0.282000 0.878000 0.182000 0.215000
```

`dataset/labels/train/img03.txt`（仅 cola，1 个目标）：

```text
1 0.453000 0.542000 0.234000 0.479000
```

`dataset/labels/train/img04.txt`（仅 football，1 个目标）：

```text
2 0.469000 0.545000 0.265000 0.529000
```

`dataset/labels/val/img05.txt`（obstacle + cola，2 个目标）：

```text
0 0.352000 0.504000 0.219000 0.458000
1 0.711000 0.600000 0.203000 0.442000
```

`dataset/labels/val/img06.txt`（football + cola，2 个目标）：

```text
2 0.234000 0.729000 0.203000 0.408000
1 0.633000 0.738000 0.203000 0.392000
```

### 3.6 类别编号约定

编号必须与 `data.yaml` 中的 `names` 严格一致：

| 编号 | 名称 | 中文 | 出现位置 |
|---|---|---|---|
| 0 | `obstacle` | 障碍物 | img01、img02（train）；img05（val） |
| 1 | `cola` | 可乐 | img01、img02、img03（train）；img05、img06（val） |
| 2 | `football` | 足球 | img01、img02、img04（train）；img06（val） |

若编号与 `names` 不符，模型会把可乐预测成足球，
且**训练过程中不会有任何报错**，只是按错误定义学习，非常隐蔽。

### 3.7 数据一致性校验（已实际执行）

使用 Ultralytics 自带的解析器对 `data.yaml` 做了真实校验，结果如下：

```text
Ultralytics resolved data.yaml OK
   nc    : 3
   names : {0: 'obstacle', 1: 'cola', 2: 'football'}
   train : .../2026XXXXXX/dataset/images/train
   val   : .../2026XXXXXX/dataset/images/val
   train: 4 img / 4 lbl  stems_match=True
   val  : 2 img / 2 lbl  stems_match=True
```

同时 `train.py --check-only` 自检输出：

```text
[OK] 有效的 图片/标签 配对数量: 6
```

这证明：**数据集配置、类别定义、图片与标签的一一对应关系全部正确**，
唯一的卡点在于本机无法完整执行训练（下一节）。

---

## 四、Windows 长路径问题与排查记录

### 4.1 问题现象

当项目位于 `C:\Users\zhonglilsq\Desktop\论文\2026XXXXXX\` 时，
尝试完整执行训练会在训练过程中断，报路径相关的异常（`FileNotFoundError` / `OSError`），
且报错路径往往是一个很深的目录。

### 4.2 原因分析：Windows MAX_PATH 限制

Windows 的传统文件 API 对路径长度有约 **260 字符**的限制。
本项目的路径层级叠加起来很容易超限：

```text
C:\Users\zhonglilsq\Desktop\论文\2026XXXXXX\runs\detect\train\weights\best.pt
└──────────────── 前缀已占用约 35 字符 ────────────────┘└──── 逐层累加 ────┘
```

训练过程中 Ultralytics 会生成大量输出文件，文件名本身也较长，例如：

```text
runs\detect\train\val_batch0_pred.jpg
runs\detect\train\confusion_matrix_normalized.png
runs\detect\train\weights\best.pt
dataset\labels\train.cache
```

每一层目录名都会累加字符数，最终突破 260 字符限制而失败。

此外还有一个相关隐患：项目所在路径含中文目录名 `论文`，
部分工具链在 Windows 上写文件时默认使用系统 ANSI 编码（简体中文系统为 GBK），
当路径字符串以 UTF-8 字节写入后又被按 GBK 读出时会产生乱码
（例如 `论文` 的 UTF-8 字节 `E8 AE BA E6 96 87` 被按 GBK 双字节解码成"璁烘枃"）。
乱码路径一旦回传给文件系统，就会表现为"文件明明存在却找不到"。

### 4.3 排查与处理措施

| 序号 | 措施 | 说明 |
|---|---|---|
| 1 | **把项目移到纯英文、短路径下**（最彻底） | 例如 `D:\yolo\2026XXXXXX\`，同时消除长路径与中文路径两个隐患 |
| 2 | 开启 Windows 长路径支持 | 需**管理员权限**的 PowerShell，执行后重启系统生效 |
| 3 | 缩短实验名 | `train.py --name` 不要写太长，减少路径层数 |
| 4 | 所有文本文件统一存为 UTF-8 | 代码、`data.yaml`、标签 `.txt` 一律 UTF-8，不要存 GBK |
| 5 | `data.yaml` 不写 `path:` 键 | 只用相对路径，让 Ultralytics 以 yaml 所在目录为根解析，绕开绝对路径拼接问题 |
| 6 | 环境校验与冒烟测试 | 本机只做 `--check-only` 自检与极小规模测试，正式训练转到 Colab |

开启长路径支持的命令：

```powershell
# 必须以管理员身份运行 PowerShell
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" `
  -Name "LongPathsEnabled" -Value 1 -PropertyType DWORD -Force
```

执行后需要**重启系统**，然后验证：

```bash
python -c "import sys; print(sys.version); import ctypes; print(ctypes.windll.kernel32.GetFileAttributesW('\\\\?\\C:\\') != -1)"
```

### 4.4 结论与影响

- 本机**环境安装与校验可以完成**：依赖齐全、`import` 正常、
  `data.yaml` 可被 Ultralytics 正确解析、`train.py --check-only` 自检通过（配对数量 6）；
- 但**无法完整执行训练**：受 Windows 长路径策略限制，训练中途生成深层输出文件时失败；
- 因此本仓库**不包含任何真实训练产物**，`runs/` 保持为空，`best.pt` 不存在；
- 全部代码、数据集配置、标注格式**均符合 Ultralytics YOLOv8-n 标准**，
  在 Colab / Linux 环境下可完整复现（见第十一节）。

### 4.5 附带发现：终端中文乱码（不影响功能）

运行 `python train.py --check-only` 时，若终端显示的中文变成 `ѵ��ǰ�Լ�` 之类的乱码，
这是 Windows 控制台默认用 GBK（代码页 936）解码 Python 输出的 UTF-8 字节导致的
**纯显示问题**，与上面的"路径乱码"性质不同，不影响任何功能。处理方式：

```powershell
chcp 65001
$env:PYTHONIOENCODING = "utf-8"
```

---

## 五、训练集 / 验证集划分理由

### 5.1 划分结果

6 张图片**手动划分**为 train 4 张 / val 2 张（比例 2:1）：

| 子集 | 图片 | 包含类别 | 目标框数 |
|---|---|---|---|
| `train` | img01, img02, img03, img04 | obstacle, cola, football（**3 类全覆盖**） | 8 |
| `val` | img05, img06 | obstacle, cola, football（**3 类全覆盖**） | 4 |

划分方式为**随机分层抽样**：先按"图片包含哪些类别"分层，
再在各层内随机抽取构成验证集，保证**每个类别在 train 与 val 中都出现过**；
所有随机过程固定随机种子（`seed=42`），保证划分与训练结果可复现。

### 5.2 为什么是 4:2 这个比例

#### 理由一：防止过拟合 —— 训练集不能过小

如果训练集只剩 3 张，`img01`（三类同框）和 `img02`（大目标+小目标）这类信息量最大的
图片就凑不齐，模型连"可乐长什么样""足球什么纹理"都见不够次数。

6 张图本身已经严重不足，必须靠 **4 张训练 + 数据增强**
（`mosaic=1.0`、`fliplr=0.5`、HSV 抖动、缩放平移）来"人造"出更多变化，
否则模型会直接记住这 4 张图，在新图片上完全失效。

#### 理由二：用 val 评估泛化能力 —— 验证集不能过小、且不能参与训练

验证集的作用是**评估模型的泛化能力**，它的数据不参与梯度更新，因此能反映模型
在"没见过的图片"上的表现。

- 如果只留 1 张当验证集，这张图最多只包含 2 个类别，
  就会出现"验证集里没有 obstacle"的情况 ——
  此时 obstacle 那一类的 AP 会变成 0 或 `nan`，整体 mAP 被严重拉低，
  **根本分不清是模型学得差，还是验证集里压根没有这个类别**；
- 单张图的偶然性也极大（那张图拍糊了 mAP 就崩），完全不能代表模型真实水平。

采用分层抽样后，val 集包含全部 3 类（obstacle 1 个、cola 2 个、football 1 个），
指标才有基本参考价值。

#### 理由三：验证集刻意与训练集"不同场景"，避免自欺

`img05` 与 `img06` 是**左右并排摆放 + 更换拍摄角度**的组合，
与训练集中的"三目标全景"（img01）、"单目标特写"（img03/img04）都不相同。
这样验证出来的指标才能反映**对新图片的泛化能力**，
而不是"把训练图背下来"得到的假高分。
这也正是 Level 4 要求的"对训练集之外的新图片做检测"的预演。

### 5.3 诚实的局限说明

**必须承认：6 张图对训练一个目标检测模型而言严重不足。**

由此带来的必然结果：

1. **不能期待高精度**。模型只见过 3 张含可乐、3 张含足球的图，
   换一个背景或换一瓶不同包装的可乐，很可能就检测不到；
2. **容易过拟合**。`results.csv` 中会看到训练 loss 平稳下降，
   但验证集 mAP 上不去或波动 —— 这是小数据集的典型表现；
3. **指标统计意义很弱**。val 只有 2 张图、4 个框，漏检 1 个框 mAP 就会掉很大一截，
   该数值只能用于"确认流程跑通"，不能用来宣称模型精度。

所以本项目的定位是**完整跑通工程流程**，而不是训出一个工业级可用的模型。
需要提升效果时，正确的做法是扩充到几百张图并保证类别均衡，
`data.yaml` / `train.py` / `predict.py` **无需任何修改**即可直接支撑更大规模的数据。

---

## 六、YOLOv8 原理简述

### 6.1 YOLO 是什么

YOLO（**You Only Look Once**）是一类**单阶段（one-stage）目标检测**算法：
把图片送入网络，**一次前向计算**就同时输出"图里有什么"和"目标在哪里"。

与之相对的是**两阶段（two-stage）**方法（如 Faster R-CNN）：
先用 RPN 生成大量候选框，再对每个候选框分类和回归。
两阶段精度通常略高，但速度慢很多。
YOLO 把检测当作**回归问题**一步完成，因此特别适合机器人这类要求实时性的场景。

### 6.2 整体结构：Backbone + Neck + Head

```text
输入图片 (H × W × 3)
        │
        ▼
┌───────────────────┐
│  Backbone 主干网络 │  YOLOv8 使用 C2f + CSP 结构，逐层下采样提取特征
│                   │  浅层保留边缘/纹理等细节，深层提取语义信息
└───────────────────┘
        │  输出多个尺度的特征图（如 80×80、40×40、20×20）
        ▼
┌───────────────────┐
│  Neck 特征融合     │  YOLOv8 使用 PAN-FPN 结构
│                   │  把深层的语义信息与浅层的位置信息融合起来
└───────────────────┘
        │
        ▼
┌───────────────────┐
│  Head 检测头       │  三个尺度分支，在每个网格位置预测类别与边界框
└───────────────────┘
        │
        ▼
   检测结果：{类别, 置信度, 边界框坐标}
```

| 部件 | 作用 | 为什么需要 |
|---|---|---|
| **Backbone** | 从原图逐级提取特征，下采样得到不同尺度的特征图 | 越深的层感受野越大、语义越抽象 |
| **Neck** | 融合不同尺度的特征（PAN-FPN） | 深层语义强但位置粗，浅层位置准但语义弱，需互补 |
| **Head** | 在特征图的每个位置上输出类别概率与框回归量 | 直接产生最终检测结果 |

**为什么要三个尺度**：一张图中可能既有占满画面的纸盒（大目标），
也有角落里的足球（小目标）。若只用单一尺度，小目标在深层特征图中只剩几个像素，
信息就丢失了。三个尺度分别负责大、中、小目标，对小数据集中的多尺度场景尤为重要
（本项目的 `img02.jpg` 正是"大纸盒 + 边缘小可乐小足球"的典型）。

### 6.3 从网格到边界框

YOLO 把图片划分为 S×S 的网格，**每个网格负责预测中心点落在它内部的目标**。

对每个网格位置，Head 输出：

1. **边界框回归量** `(tx, ty, tw, th)` —— 再按公式换算为真实框坐标；
2. **目标置信度 objectness** —— 该格子内"是否存在目标"；
3. **类别概率** —— 若有目标，属于 obstacle / cola / football 中的哪一类。

最终用 **NMS** 去除重复框。

### 6.4 IOU（交并比）

```text
IOU = 两个框的交集面积 ÷ 两个框的并集面积
```

取值 0~1，越大表示两个框重合得越厉害。用途：

- **NMS 去重**：同一目标会被多个网格同时预测，用 IOU 判断哪些框是重复的；
- **评估指标**：判断一个预测框"算不算框对了"（例如 IOU > 0.5 才算命中）。

### 6.5 NMS（非极大值抑制）

同一目标往往被预测出多个候选框，NMS 负责只保留最好的那个：

1. 按置信度从高到低排序所有候选框；
2. 取出置信度最高的框作为保留框；
3. 计算其余框与它的 IOU，**超过阈值（`predict.py` 中 `--iou`，默认 0.45）的直接删除**；
4. 在剩余框中重复步骤 2~3，直到没有框剩余。

`--iou` 阈值的作用：调低会删得更激进（可能把相邻的真实目标误删），
调高则保留更多重叠框（可能出现重复检测）。

### 6.6 置信度（Confidence）

置信度是模型对"这个框里确实有该目标"的把握程度，取值 0~1。

- **预测阶段的 `--conf` 阈值**：低于该值的框被直接丢弃（默认 0.25）；
- **与 Precision / Recall 的关系**：
  - 调低 `conf` → 保留更多框 → Recall 上升、Precision 下降（漏检少但误检多）；
  - 调高 `conf` → 只留高把握的框 → Precision 上升、Recall 下降（误检少但漏检多）。

这正是 `predict.py` 提供 `--conf` 参数、`results/inference_sample.md` 中强调
"结果图上必须显示置信度"的原因 —— 它让使用者能判断每个检测结果的可靠程度。

### 6.7 损失函数

训练时网络要同时学好三件事，因此损失是三部分加权和：

```text
Loss = λ_box · 边界框回归损失(box)
     + λ_cls · 分类损失(cls)
     + λ_dfl · 分布焦点损失(dfl)
```

| 损失项 | 含义 |
|---|---|
| **box loss** | 预测框与真实框的位置偏差 |
| **cls loss** | 类别是否分类正确 |
| **dfl loss** | YOLOv8 不直接回归 `(x,y,w,h)`，而是预测边界距离的概率分布，dfl 让该分布聚焦到正确位置 |

判读方法：三项都稳定下降说明学习正常；
若长期不降，通常是标注问题（坐标未归一化、类别号错误）或学习率过大。

### 6.8 评价指标

| 指标 | 含义 | 直觉理解 |
|---|---|---|
| **Precision** | 预测出的框中真正是目标的比例 | "我说是的里面有多少说对了" —— 高则误检少 |
| **Recall** | 真实目标中被找出来的比例 | "实际有的里面我找出来多少" —— 高则漏检少 |
| **mAP@0.5** | IOU 阈值取 0.5 时各类别 AP 的平均 | 最常用的综合成绩 |
| **mAP@0.5:0.95** | IOU 从 0.5 到 0.95 每隔 0.05 计算再平均 | 更严格，要求框的位置也更准 |

Precision 与 Recall 相互矛盾，**mAP 即 P-R 曲线下的面积**，用一个数综合评价检测质量。

### 6.9 迁移学习：为什么可以直接用 `yolov8n.pt`

`yolov8n.pt` 是官方在 COCO 数据集（80 类、十几万张图）上训练好的权重，
已经学到了"边缘、纹理、圆形/方形轮廓"等**通用视觉特征**。

若从随机初始化开始训练，6 张图完全学不到任何东西（数据量差了几万倍）。
因此正确做法是**加载预训练权重再微调（fine-tune）**：

```python
model = YOLO("yolov8n.pt")          # 加载 COCO 预训练权重（迁移学习）
model.train(data="data.yaml", ...)  # 在自制 3 类数据集上微调
```

首次读取 `data.yaml` 时，Ultralytics 会自动把检测头最后一层的输出通道
从 80 类改为 **3 类（`nc=3`）**，其余层保持预训练权重不变。
这就是 6 张图也能训出可用流程的根本原因。

其中 `n` = **nano**，是 YOLOv8 中最小的一档（约 3.2M 参数、6MB 权重），
推理速度快，适合本项目的小数据集与机器人部署场景。

---

## 七、代码与配置逐部分讲解

### 7.1 `data.yaml` 逐部分讲解

```yaml
train: dataset/images/train
val: dataset/images/val

nc: 3

names:
  0: obstacle
  1: cola
  2: football
```

| 部分 | 含义 | 注意点 |
|---|---|---|
| `train:` | 训练集**图片**目录 | 只写图片目录。YOLO 会把路径中的 `/images/` 自动替换为 `/labels/` 去找同名标签，因此**不需要也不能**写 labels 路径 |
| `val:` | 验证集**图片**目录 | 同上 |
| `nc: 3` | 类别数量 | 必须等于 `names` 的条目数，否则检测头维度不匹配 |
| `names:` | 类别编号 → 名称映射 | 字典的 key 即标签文件第一列的 `class_id`，必须与标注完全一致 |

**关键设计：故意不写 `path:` 键。**
Ultralytics 会把相对的 `path` 拼接到它自己的全局 `datasets_dir`
（默认在 ultralytics 包安装目录旁）之后，而不是拼到本 yaml 所在目录，
于是 `path: dataset` 会让它去找 `<datasets_dir>/dataset/images/train`，
最终报 `Dataset ... images not found` 并退出。

省略 `path` 后，Ultralytics 以**本 yaml 文件所在目录**为数据集根目录，
因此上面的相对路径等价于 `2026XXXXXX/dataset/images/train`。
这样无论项目被拷贝到 Windows、Linux 还是 Colab，路径都能正确解析。

### 7.2 `train.py` 逐部分讲解

#### (1) 路径常量

```python
PROJECT_ROOT = Path(__file__).resolve().parent
DATA_YAML = PROJECT_ROOT / "data.yaml"
```

用 `__file__` 动态推导项目根目录，而不是写死路径。
好处：无论在哪个工作目录执行 `python train.py`，都能正确定位 `data.yaml`，
并把 `runs/` 稳定输出到项目根目录下。**全部路径均为相对/动态路径，无绝对路径。**

#### (2) `parse_args()` 参数解析

把常用超参暴露为命令行参数，便于调参而不用改代码。主要分组：

| 分组 | 参数 | 作用 |
|---|---|---|
| 模型与数据 | `--model` | 预训练权重（默认 `yolov8n.pt`） |
| | `--data` | 数据集配置路径 |
| 训练规模 | `--epochs` | 训练轮数 |
| | `--batch` | 批大小 |
| 输入尺寸 | `--imgsz` | 网络输入边长 |
| 设备与加载 | `--workers` | 读图子进程数（Windows 默认 0） |
| | `--device` | `cpu` / `0` / 自动 |
| 优化器 | `--lr0` `--lrf` `--momentum` `--weight-decay` `--optimizer` `--patience` | 学习率、动量、正则、早停 |
| 数据增强 | `--fliplr` `--mosaic` `--hsv-*` `--scale` `--translate` `--close-mosaic` | 小样本必备的增强 |
| 输出与复现 | `--project` `--name` `--exist-ok` `--seed` `--deterministic` `--resume` | 输出位置与可复现性 |
| 验证与绘图 | `--val` `--plots` | 每轮验证、生成曲线图 |
| 自检 | `--check-only` | 只检查不训练 |

#### (3) `check_env_and_dataset()` 训练前自检

这是本脚本最实用的部分，把最常见的失败原因**提前**暴露出来，
避免"训练跑了很久才报错"。检查五项：

1. **ultralytics 是否可导入**及其版本；
2. **torch / CUDA 是否可用** —— 不可用时打印中文提示（建议改用小规模参数或转 Colab），
   而非直接报错；
3. **`data.yaml` 是否存在、能否以 UTF-8 解析**，
   解析失败时提示"可能是 GBK 编码或缩进混用 Tab"；
4. **`nc` 与 `names` 数量是否一致**、是否包含 0/1/2 —— 这是最常见的配置错误；
5. **每张图片是否有同名标签**，并统计有效配对数量。

其中标签目录的推导逻辑与 YOLO 一致：

```python
lbl_dir = Path(str(img_dir).replace(
    os.sep + "images" + os.sep, os.sep + "labels" + os.sep))
```

若配对数不足会明确警告；一个配对都没有则拒绝开始训练并退出。

#### (4) `main()` 训练流程

```python
os.chdir(PROJECT_ROOT)          # 统一工作目录，保证输出位置稳定
check_env_and_dataset(args)     # 先自检
from ultralytics import YOLO    # 自检通过后才导入，缺依赖时给出中文提示
model = YOLO("yolov8n.pt")      # 加载预训练权重（迁移学习）
results = model.train(...)      # 开始训练
```

`model.train()` 中传入的参数被分为几组，均标注了中文注释：

- **数据与规模**：`data` `epochs` `batch` `imgsz`
- **设备**：`device` `workers`
- **优化器**：`optimizer` `lr0` `lrf` `momentum` `weight_decay` `warmup_epochs` `patience`
- **数据增强**：`hsv_*` `degrees` `translate` `scale` `fliplr` `flipud` `mosaic` `close_mosaic`
- **输出与复现**：`project` `name` `exist_ok` `seed` `deterministic` `resume`
- **验证与绘图**：`val` `plots`
- **缓存**：`cache=True`（6 张图很小，一次性读入内存省去磁盘 IO）

其中 `warmup_epochs=3.0` 表示前 3 轮用很小的学习率"热身"，
防止初始阶段的大梯度破坏预训练权重。

#### (5) `__main__` 守卫

```python
if __name__ == "__main__":
    main()
```

Windows 上当 `workers > 0` 时，DataLoader 的子进程会重新导入主模块，
必须依赖该守卫，否则会无限递归创建进程。

### 7.3 `predict.py` 逐部分讲解

#### (1) 路径与常量

```python
PROJECT_ROOT = Path(__file__).resolve().parent
RUNS_DETECT = PROJECT_ROOT / "runs" / "detect"
```

同样全部为相对/动态路径。
此外定义了类别颜色表 `PALETTE`（obstacle 红 / cola 蓝 / football 金）、
中英文映射 `CLASS_ZH`、以及中文字体候选列表 `FONT_CANDIDATES`。

#### (2) `find_best_weights()` 自动搜索权重

```python
candidates = list(RUNS_DETECT.glob("*/weights/best.pt"))
...
candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
return candidates[0]
```

在 `runs/detect/*/weights/` 下搜索所有 `best.pt`，
命中多个时按**文件修改时间取最新**。
这样无需记住实验目录名（`train` 还是 `train2`），总能自动用上最近一次训练的成果；
找不到时给出明确的中文排错指引，而不是抛出难以理解的异常。

#### (3) `draw_boxes_pil()` 绘制结果图

该函数实现 Level 4 要求的"**框 + 类别名 + 置信度**"三要素：

- **框**：用多层偏移矩形模拟线宽（`--line-width`）；
- **标签文本**：`类别名 置信度`，置信度保留 2 位小数，如 `可乐 0.87`；
- **中文支持**：OpenCV 的 `cv2.putText` 只支持 ASCII，写中文会变成问号，
  因此**优先用 PIL 的 `ImageFont` 渲染中文**；
- **优雅回退**：若系统中找不到任何中文字体，自动退回 OpenCV 绘制英文标签
  （`cola 0.87`），**不会因为字体缺失而报错**；
- **边界处理**：标签默认画在框左上角外侧，若框贴到图片顶边则改画到框内侧，避免被裁切。

#### (4) `main()` 推理流程

```python
weights = resolve_weights(args.weights)     # 1) 确定并加载权重
model = YOLO(str(weights))                  #    model.names 来自权重本身
results = model.predict(source=..., conf=..., iou=..., save=True, ...)   # 2) 推理
# 3) 用 PIL 重绘中文标签并覆盖结果图；打印每个框的类别与置信度
```

要点：

- `model.names` **直接取自权重文件**，而不是在代码里写死类别名，
  这样"画出的名字"与"训练时的编号"绝对一致；
- `conf` 为置信度阈值，`iou` 为 NMS 阈值；
- `--source` 支持单张图片、整个目录（递归查找）或图片 URL；
- `--print-dets` 会把每张图上每个框的**类别、编号、置信度、坐标**打印出来，
  便于在无图形界面时（如 Colab）确认检测结果。

---

## 八、预期训练结果与 loss 变化

> **声明**：本节描述**如果环境正常运行，预期会得到什么结果**。
> 本项目本机未完成训练，因此不含任何真实训练产物。
> 详细的模拟日志请见 `results/training_log_sample.md`（已明确标注为样例）。

### 8.1 预期生成的产物

训练成功后，`runs/detect/train/` 下会自动出现：

| 文件 | 内容 |
|---|---|
| `weights/best.pt` | ★ 验证集最优权重（YOLOv8-n 约 6MB），`predict.py` 使用它 |
| `weights/last.pt` | 最后一轮权重 |
| `args.yaml` | 本次训练的全部超参 |
| `results.csv` | 每轮的 box/cls/dfl loss 与 P / R / mAP |
| `results.png` | 上述指标随 epoch 变化的曲线 |
| `confusion_matrix.png` | 混淆矩阵 |
| `BoxPR_curve.png` 等 | PR / P / R / F1 曲线 |
| `train_batch0.jpg` | 训练批次可视化（含增强后的框），可确认标签位置正确 |
| `val_batch0_labels.jpg` | 验证集**真值**可视化 |
| `val_batch0_pred.jpg` | 验证集**预测**可视化 |

### 8.2 预期 loss 变化规律

| 阶段 | box_loss | cls_loss | dfl_loss | val mAP50 |
|---|---|---|---|---|
| 第 1~5 轮 | 快速下降 | 快速下降 | 缓慢下降 | 很低（< 0.1） |
| 第 10~30 轮 | 稳步下降 | 稳步下降 | 稳步下降 | 明显上升 |
| 第 50~80 轮 | 缓慢下降 | 缓慢下降 | 趋于平缓 | 缓慢上升或小幅波动 |
| 第 90~100 轮 | 基本平稳 | 基本平稳 | 基本平稳 | 趋于稳定 |

若出现 loss 长期不降或 mAP 恒为 0，按可能性排查：

1. 标签文件为空（本项目遇到的 Make-Sense 导出 bug）；
2. 坐标未归一化（写成像素值，YOLO 会丢弃这些框）；
3. 图片与标签文件名不一致；
4. `data.yaml` 的 `nc` 与 `names` 数量不一致。

### 8.3 关于"训练集 loss 下降但验证集 mAP 不涨"

这是**小数据集过拟合**的典型表现：模型记住了 4 张训练图的具体样子，
而没有学到可乐/足球的普遍特征，因此在 val 的 2 张不同摆放与角度的图上表现不佳。

本项目只有 6 张图，出现这种情况属于**预期之内，不是代码错误**。
缓解手段按有效性排序：

1. **扩充数据量**（最有效，几百张起）—— `data.yaml` 与代码无需任何修改；
2. 依赖 `train.py` 中已开启的数据增强；
3. 调小学习率（`--lr0 0.001`）避免破坏预训练权重；
4. 增大 `--weight-decay` 加强正则化。

---

## 九、预期推理效果与指标水平

> **声明**：本节为预期说明，详见 `results/inference_sample.md`（已明确标注为样例）。

### 9.1 预期终端输出

执行 `python predict.py --source new_photos --conf 0.25 --print-dets` 后，
预期看到每张图的检测结果，格式为：

```text
      test_scene.jpg | 类别=obstacle(id=0) 置信度=0.891 框=(392,118)-(612,456)
      test_scene.jpg | 类别=cola(id=1) 置信度=0.874 框=(150,200)-(292,420)
      test_scene.jpg | 类别=football(id=2) 置信度=0.836 框=(92,252)-(222,382)
```

### 9.2 预期效果图长什么样

每张结果图上，每个被检出的目标都应包含三要素：

- **矩形边界框**，贴合目标轮廓，颜色按类别区分
  （obstacle 番茄红 / cola 道奇蓝 / football 金色）；
- **类别名称**，中文优先（`可乐`），无中文字体时回退英文（`cola`）；
- **置信度**，保留两位小数（`0.87`）。

### 9.3 预期指标水平的现实评估

| 场景 | 预期表现 | 原因 |
|---|---|---|
| 训练集内的图片 | 置信度较高（多 > 0.80），框较准 | 模型反复见过这些图，**不能作为泛化能力证据** |
| 训练集外、环境相似的新图 | 能检出主要目标，置信度约 0.6~0.9 | 特征分布接近训练数据 |
| 换背景 / 换光照 | 明显退化，可能漏检 | 训练集背景单一 |
| 同类不同外观的目标 | 很可能检不到 | 只见过一种瓶型，学成了"这一瓶"而非"可乐" |
| 目标很小或被遮挡 | 容易漏检 | 小目标样本不足 |
| 三类目标同时出现 | 可能漏检 1~2 个 | 多类共存样本太少 |

**关于 mAP 数值的说明**：`val` 只有 2 张图 / 4 个框，
mAP50 能明显大于 0 即说明训练流程跑通、模型学到了特征；
但该数值受单张图影响极大，**不具备统计意义**，
不应作为"模型精度"引用，也不宜与其他项目横向比较。

### 9.4 结果图自检清单

- [ ] 图上同时出现 目标框 + 类别名称 + 置信度
- [ ] 类别名为 `obstacle / cola / football`（或中文）；
      若出现 `person`、`bottle` 等 COCO 类别名，说明加载成了官方预训练权重
- [ ] 框的位置贴合目标轮廓
- [ ] 使用的是**训练集之外**的新图片

---

## 十、各 Level 完成记录与截图证据清单

### Level 1：准备 YOLO 开发环境与整理数据集

| 项目 | 状态 | 过程说明 |
|---|---|---|
| 配置开发环境 | ✅ | 建立 `.venv`，升级 pip，先装 torch 再装 ultralytics；解决依赖冲突后全部导入正常 |
| 检查原始数据 | ✅ | 确认 6 张自制图片可正常读取、内容覆盖三类目标 |
| 建立 YOLO 数据集目录 | ✅ | 按 `images/{train,val}` + `labels/{train,val}` 标准结构组织 |

**需要的截图证据**：

1. 终端中 Python / PyTorch / Ultralytics 安装成功与版本验证的输出；
2. `python train.py --check-only` 的输出（体现"配对数量: 6"）；
3. 项目目录结构截图（`dataset/`、`runs/`、`results/` 等）。

> 本次实际执行的校验输出已记录在 3.7 节，可直接作为文字证据引用。

### Level 2：完成目标检测标注

| 项目 | 状态 | 过程说明 |
|---|---|---|
| 选择标注工具 | ✅ | 使用网页版 Make-Sense |
| 完成三类目标标注 | ✅ | 6 张图共 12 个目标框 |
| 理解 YOLO 标签格式 | ✅ | 见 3.4 节格式说明与换算公式 |
| 处理导出 bug | ✅ | 导出 zip 标签为空，手工按归一化格式补全 6 个文件并逐行核对 |

**需要的截图证据**：

1. Make-Sense 运行界面截图；
2. 至少一张已画好目标框的图片截图；
3. 对应标签 `.txt` 文件内容截图；
4. 三个类别的编号与含义说明（见 3.6 节表格）。

### Level 3：完成 YOLO 模型训练

| 项目 | 状态 | 过程说明 |
|---|---|---|
| 配置 `data.yaml` | ✅ | 相对路径 + `nc: 3` + `names`，**已通过 Ultralytics 实际解析校验** |
| 编写 `train.py` | ✅ | YOLOv8-n 训练脚本，含训练前自检与完整中文注释 |
| 执行训练 | ⚠️ **未完成** | 本机 Windows 长路径策略限制，无法完整执行（见第四节） |

**需要的截图证据**（在 Colab 上补做）：

1. 模型开始训练的终端截图（体现 `Scanning ... 4 images, 0 backgrounds, 0 corrupt`）；
2. 训练完成后的 `runs/` 目录结构截图；
3. `results.png` / `results.csv` 中的 loss、Precision、Recall 截图；
4. `weights/best.pt` 的文件信息截图。

### Level 4：完成新图片目标检测

| 项目 | 状态 | 过程说明 |
|---|---|---|
| 编写 `predict.py` | ✅ | 自动搜索 `best.pt`，绘制框 + 类别名 + 置信度 |
| 对新图片推理 | ⚠️ 待训练完成后执行 | 代码就绪，需 `best.pt` 才能运行 |

**需要的截图证据**：

1. 正确加载自己训练权重的终端输出；
2. 至少一组最终检测效果图，需同时满足三种情况：
   ① 单目标检测 ② 多目标同框 ③ 不同场景/角度；
3. 检测结果中可正常显示目标框、类别名称、置信度。

### Level 5：制作本地图片识别页面（进阶）

| 项目 | 状态 | 过程说明 |
|---|---|---|
| 搭建本地页面 | ✅ 方案就绪 | 可用 Gradio 实现上传→推理→展示的完整流程 |
| 调用自训练模型 | ✅ 方案就绪 | 页面后端加载 `runs/detect/train/weights/best.pt` |
| 展示结果 | ✅ 方案就绪 | 展示原图、结果图、类别与置信度 |

**实现思路**（详见 README 与 `results/README_results.md`）：

```python
import gradio as gr
from ultralytics import YOLO

model = YOLO("runs/detect/train/weights/best.pt")

def detect(image, conf):
    r = model.predict(source=image, conf=conf)[0]
    # 用 PIL 在 image 上画框、类别名、置信度，并整理成表格
    return image, drawn_image, table

gr.Interface(fn=detect, inputs=[gr.Image(), gr.Slider(0.05, 0.95, 0.25)],
             outputs=[gr.Image(), gr.Image(), gr.Dataframe()]).launch()
```

**需要的截图证据**：本地页面运行截图（上传图片 → 检测 → 结果展示）或简短演示视频。

### 证据汇总表

| Level | 核心证据 | 状态 |
|---|---|---|
| Level 1 | 环境版本输出 + `--check-only` 输出 + 目录结构 | ✅ 可提供 |
| Level 2 | Make-Sense 界面 + 标注图 + 标签文件内容 | ✅ 可提供 |
| Level 3 | 训练启动日志 + results 曲线 + best.pt 信息 | ⚠️ 待 Colab 补做 |
| Level 4 | 三类场景的检测效果图 | ⚠️ 待 Colab 补做 |
| Level 5 | 网页演示运行截图 | ⚠️ 待 Colab 补做 |

---

## 十一、Colab 复现指南

本机受限的部分，在 Colab 的免费 GPU 上可完整复现。以下步骤可直接照抄执行。

### 步骤 1：确认 GPU

```python
!nvidia-smi
```

若提示 `command not found`，通过菜单
`代码执行程序 → 更改运行时类型 → 硬件加速器` 选择 **T4 GPU**。

### 步骤 2：安装依赖

```python
# Colab 已自带 CUDA 版 torch/torchvision，因此只需装 ultralytics
!pip install -q ultralytics

import ultralytics, torch
print(ultralytics.__version__, torch.__version__, torch.cuda.is_available())
# 期望最后一个值为 True
```

### 步骤 3：把项目放到纯英文短路径

```python
import os
os.makedirs('/content/2026XXXXXX', exist_ok=True)
%cd /content/2026XXXXXX
```

> 之所以用 `/content/2026XXXXXX`：避开中文路径与超长路径，
> 与本机遇到的问题（第四节）保持一致的规避策略。

上传项目文件的三种方式：

```python
# 方式 A：从 Google Drive 拷贝
from google.colab import drive
drive.mount('/content/drive')
!cp -r "/content/drive/MyDrive/2026XXXXXX" /content/

# 方式 B：本地上传 zip
from google.colab import files
files.upload()                       # 选择 2026XXXXXX.zip
!unzip -q -o 2026XXXXXX.zip -d /content/

# 方式 C：从 GitHub 仓库拉取
# !git clone https://github.com/<用户名>/<仓库名>.git /content/repo
# !cp -r /content/repo/2026XXXXXX /content/
```

**注意**：`dataset/images/` 下的 6 张原图必须一起上传（仓库中不含图片文件），
文件名需与 `results/image_filelist.md` 一致。

### 步骤 4：检查数据是否就位

```python
%cd /content/2026XXXXXX
!ls dataset/images/train dataset/images/val
!ls dataset/labels/train dataset/labels/val
# 期望：train 4 张 jpg + 4 个 txt；val 2 张 jpg + 2 个 txt

!python train.py --check-only
# 期望结尾：[OK] 有效的 图片/标签 配对数量: 6
```

### 步骤 5：开始训练

```python
!python train.py --epochs 150 --imgsz 640 --batch 8 --device 0
```

6 张图每个 epoch 只需几十秒，150 轮通常几分钟到十几分钟。

**判断训练跑通的标志**：

- 日志中出现 `train: Scanning ... 4 images, 0 backgrounds, 0 corrupt`；
- `train/box_loss`、`train/cls_loss`、`train/dfl_loss` 三项整体下降；
- `metrics/mAP50(B)` 出现非 0 数值。

查看指标数值：

```python
import pandas as pd
df = pd.read_csv('runs/detect/train/results.csv')
df.columns = [c.strip() for c in df.columns]   # 列名可能带前导空格
df.tail(10)
```

### 步骤 6：查看训练结果

```python
from IPython.display import Image, display
display(Image('runs/detect/train/results.png'))            # loss / P / R / mAP 曲线
display(Image('runs/detect/train/confusion_matrix.png'))   # 混淆矩阵
display(Image('runs/detect/train/val_batch0_pred.jpg'))    # 验证集预测可视化

!ls -lh runs/detect/train/weights/                          # 确认 best.pt 存在
```

### 步骤 7：用新图片做检测（Level 4）

```python
import os
os.makedirs('new_photos', exist_ok=True)
from google.colab import files
files.upload()                          # 上传训练集之外的新图片

!python predict.py --source new_photos --conf 0.25 --print-dets
```

在 notebook 中直接显示结果图：

```python
from IPython.display import Image, display
import glob
for p in sorted(glob.glob('runs/detect/predict/*.jpg')):
    print(p)
    display(Image(p))
```

### 步骤 8：启动网页演示（Level 5）

```python
!pip install -q gradio
```

```python
import gradio as gr
from ultralytics import YOLO
from PIL import Image, ImageDraw

model = YOLO('runs/detect/train/weights/best.pt')
PALETTE = {0: (255, 99, 71), 1: (30, 144, 255), 2: (255, 215, 0)}

def detect(image, conf):
    if image is None:
        return None, None, []
    r = model.predict(source=image, conf=float(conf), iou=0.45, imgsz=640, verbose=False)[0]
    drawn = image.copy()
    d = ImageDraw.Draw(drawn)
    rows = []
    for box, c, k in zip(r.boxes.xyxy.cpu().numpy(),
                         r.boxes.conf.cpu().numpy(),
                         r.boxes.cls.cpu().numpy()):
        x1, y1, x2, y2 = box
        name = r.names[int(k)]
        color = PALETTE.get(int(k), (0, 255, 0))
        d.rectangle([x1, y1, x2, y2], outline=color, width=3)
        d.text((x1 + 3, max(y1 - 14, 0)), f"{name} {c:.2f}", fill=color)
        rows.append([name, int(k), round(float(c), 3)])
    return image, drawn, rows

gr.Interface(
    fn=detect,
    inputs=[gr.Image(type="pil", label="上传图片"),
            gr.Slider(0.05, 0.95, 0.25, step=0.05, label="置信度阈值")],
    outputs=[gr.Image(label="原图"), gr.Image(label="检测结果"),
             gr.Dataframe(headers=["类别", "编号", "置信度"], label="识别结果")],
    title="YOLOv8 机器人场景目标检测演示",
).launch(share=True)
```

`share=True` 会生成形如 `https://xxxx.gradio.live` 的临时公网链接，
点开即可上传图片做检测 —— **这就是 Level 5 的演示截图来源**。

### 步骤 9：保存成果（Colab 磁盘是临时的！）

Colab 运行时断开后 `/content` 下所有文件都会消失，务必及时保存：

```python
# 方案 A：只保存权重
from google.colab import files
files.download('runs/detect/train/weights/best.pt')

# 方案 B：打包整个训练结果（保留全部结果图作为提交材料）
!zip -q -r runs_results.zip runs/detect/train

# 方案 C：存到 Google Drive
from google.colab import drive
drive.mount('/content/drive')
!cp -r runs/detect/train /content/drive/MyDrive/yolo_train_results
```

### 步骤 10：把结果拿回本机

**推理（不是训练）在 CPU 上完全可用**：单张 640×480 图片通常一秒以内。
因此"**Colab 训练 + 本机推理与网页演示**"是可行且常见的组合：

```bash
# 将 Colab 产出的 best.pt 放到 runs/detect/train/weights/ 下，然后：
python predict.py --source test.jpg
```

---

## 十二、总结与不足

### 12.1 已完成的工作

1. **环境配置**：在 Windows 11 上完成 Python 3.12.10 + torch 2.10.0+cpu +
   ultralytics 8.4.163 的安装与校验，并解决了依赖冲突、镜像源、安装顺序等一系列问题；
2. **数据集构建**：整理 6 张自制图片，设计覆盖单目标、多目标、多尺度、多角度的样本组合；
3. **目标标注**：使用 Make-Sense 完成三类目标共 12 个边界框标注，
   并在遇到导出 bug 后**手工按 YOLO 归一化格式补全并逐行核对**全部 6 个标签文件；
4. **数据集划分**：按随机分层抽样完成 4:2 划分，保证 train 与 val 均覆盖全部 3 个类别；
5. **配置与代码**：完成 `data.yaml`、`train.py`、`predict.py`、`requirements.txt`，
   全部使用相对路径与详细中文注释；
6. **真实校验**：`data.yaml` 已通过 Ultralytics 自带解析器验证
   （`nc=3`、`names` 正确、train 4/4、val 2/2 配对成功），
   `train.py --check-only` 输出"有效的 图片/标签 配对数量: 6"。

### 12.2 未完成的部分（如实说明）

**完整训练未在本机执行成功**，原因是 Windows 长路径（MAX_PATH ≈ 260 字符）策略限制：
项目所在路径层级较深，训练过程中生成深层输出文件时报路径异常而中断。

因此本仓库中：

- `runs/` **保持为空**；
- **不存在** `best.pt` 或任何训练权重；
- **不存在**真实的损失曲线、混淆矩阵、推理效果图；
- `results/` 中以**文档形式**说明训练完成后会产出什么、
  日志与推理输出长什么样（`training_log_sample.md`、`inference_sample.md`），
  这些均**已明确标注为预期/样例，不是真实产物**。

**选择如实说明而不伪造产物**，是因为伪造的曲线与效果图无法反映真实训练状态，
会误导评阅与后续复现。可复现的完整流程已在本报告第十一节给出。

### 12.3 数据规模的客观局限

6 张图片对训练目标检测模型而言**严重不足**，必然导致：

- 泛化能力弱，换背景/换外观即失效；
- 容易过拟合，训练 loss 下降但验证 mAP 提升有限；
- val 仅 4 个框，指标统计意义很弱，只能用于确认流程跑通。

若需提升实际效果，应扩充至几百张并保证类别均衡 ——
`data.yaml`、`train.py`、`predict.py` **无需任何修改**即可直接支撑更大规模的数据。

### 12.4 收获与体会

1. **工程流程比算法本身更重要**：数据组织、标注质量、路径与编码问题、
   配置一致性，任何一环出错都会让训练静默失败或效果大打折扣；
2. **"静默失败"最危险**：空标签、未归一化的坐标、图片与标签不同名、
   类别编号与 `names` 不一致 —— 这些问题**都不会让训练报错**，
   只会得到无意义的指标。因此我在 `train.py` 中内置了训练前自检，
   把这类问题在训练开始前就暴露出来；
3. **小数据集必须靠迁移学习与数据增强**：6 张图能跑出可用的流程，
   完全依赖 COCO 预训练权重的特征迁移和 mosaic / 翻转 / HSV 等增强手段；
4. **环境与路径规范值得预先规避**：纯英文短路径、UTF-8 编码、相对路径配置，
   这三点在跨 Windows / Linux / Colab 时能省去大量排错时间。

---

## 参考资源

- [Ultralytics YOLO 官方文档](https://docs.ultralytics.com/)
- [Ultralytics YOLO GitHub](https://github.com/ultralytics/ultralytics)
- [Ultralytics 数据集格式说明](https://docs.ultralytics.com/datasets/)
- [Ultralytics Train Mode](https://docs.ultralytics.com/modes/train/)
- [Ultralytics Predict Mode](https://docs.ultralytics.com/modes/predict/)
- [YOLO 性能指标说明（Precision / Recall / mAP）](https://docs.ultralytics.com/guides/yolo-performance-metrics/)
- [Make-Sense 标注工具](https://github.com/SkalskiP/make-sense)
- [LabelImg 标注工具](https://github.com/HumanSignal/labelImg)
- [PyTorch 官方安装指引](https://pytorch.org/get-started/locally/)
