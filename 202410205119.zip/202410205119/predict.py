#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
predict.py —— 加载自己训练得到的 best.pt，对新图片做目标检测并保存画框结果
================================================================================
项目位置: 2026XXXXXX/predict.py

【概念区分】
    训练(train) = 用标注好的图片调整模型权重，权重会改变；
    推理(infer) = 用已训练好的权重做前向计算，权重固定不变。
    因此本脚本中不会出现 optimizer / loss.backward() 等训练相关代码。

【运行方式】（在本文件所在目录下执行）
    # 1) 检测单张图片
    python predict.py --source test.jpg

    # 2) 检测整个目录下的所有图片
    python predict.py --source ./my_new_photos --conf 0.25

    # 3) 显式指定权重（默认自动搜索 runs/detect/*/weights/best.pt）
    python predict.py --weights runs/detect/train/weights/best.pt --source test.jpg

    # 4) 同时把每个框的类别与置信度打印到终端
    python predict.py --source test.jpg --print-dets

【输出】
    runs/detect/predict/<原文件名>.jpg    画好框的结果图
    （重复运行会依次生成 predict2、predict3……）

【验收要求对应】结果图上同时呈现三项信息：
    ① 目标边界框   ② 类别名称   ③ 置信度

【路径规范】全部使用相对路径 + 基于 __file__ 的动态路径，无任何 C:/ D:/ 绝对路径。
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# 0. 路径与常量（均相对项目根目录推导，可移植）
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent
RUNS_DETECT = PROJECT_ROOT / "runs" / "detect"

# 支持的图片后缀白名单
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}

# 类别英文名 -> 中文显示名（画图时用中文更直观，可用 --no-zh 关闭）
CLASS_ZH = {"obstacle": "障碍物", "cola": "可乐", "football": "足球"}

# 每类固定一种颜色，便于人眼区分（RGB 元组）
PALETTE = {
    0: (255, 99, 71),    # obstacle -> 番茄红
    1: (30, 144, 255),   # cola     -> 道奇蓝
    2: (255, 215, 0),    # football -> 金色
}

# 中文字体候选路径：依次尝试 Windows / Linux / macOS 常见字体。
# 原因：OpenCV 的 cv2.putText 只支持 ASCII，写中文会变成问号，
#       所以中文标签必须用 PIL 的 ImageFont 渲染。
# 若一个都找不到，则自动回退为英文标签（功能不受影响，只是显示语言变化）。
FONT_CANDIDATES = [
    r"C:\Windows\Fonts\msyh.ttc",                                  # Windows 微软雅黑
    r"C:\Windows\Fonts\simhei.ttf",                                # Windows 黑体
    r"C:\Windows\Fonts\simsun.ttc",                                # Windows 宋体
    "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",                # Linux 文泉驿正黑
    "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",      # Linux Noto CJK
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",             # Linux 兜底（无中文）
    "/System/Library/Fonts/PingFang.ttc",                          # macOS 苹方
]


def parse_args() -> argparse.Namespace:
    """解析命令行参数。"""
    p = argparse.ArgumentParser(
        description="加载训练得到的 best.pt，对新图片做目标检测并保存画框结果",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # --weights 留空即启用"自动搜索"，见 find_best_weights()
    p.add_argument("--weights", default="",
                   help="模型权重路径；留空则自动搜索 runs/detect/*/weights/best.pt")
    p.add_argument("--source", required=True,
                   help="待检测对象：单张图片 / 图片目录 / 图片URL")

    # conf：置信度阈值。低于该值的预测框直接丢弃。
    #   调低(0.10) -> 框更多但误检增加，Recall 上升、Precision 下降；
    #   调高(0.50) -> 只保留高置信度框，Precision 上升、Recall 下降。
    p.add_argument("--conf", type=float, default=0.25, help="置信度阈值")
    # iou：NMS 的 IoU 阈值，用于剔除同一目标上的重复框。
    #   两个框的交并比超过该阈值时，只保留分数更高的那个。
    p.add_argument("--iou", type=float, default=0.45, help="NMS 的 IoU 阈值")
    # imgsz：推理输入尺寸，建议与训练时保持一致（本项目 640）。
    p.add_argument("--imgsz", type=int, default=640, help="推理输入边长")
    p.add_argument("--device", default="", help="cpu / 0；留空为自动")

    # 结果输出位置与命名
    p.add_argument("--project", default=str(RUNS_DETECT), help="结果输出根目录")
    p.add_argument("--name", default="predict", help="结果子目录名")
    p.add_argument("--exist-ok", action="store_true", help="允许覆盖同名输出目录")

    # 可选：额外把检测框以 YOLO 格式保存为 txt，便于后续统计
    p.add_argument("--save-txt", action="store_true", help="同时保存 YOLO 格式结果 txt")
    p.add_argument("--save-conf", action="store_true", help="txt 中附带置信度（需配合 --save-txt）")

    # 绘图相关
    p.add_argument("--line-width", type=int, default=2, help="检测框线宽")
    p.add_argument("--no-zh", action="store_true", help="标签仅用英文类别名")
    p.add_argument("--print-dets", action="store_true", help="在终端打印每个框的类别与置信度")
    return p.parse_args()


def find_best_weights() -> Path:
    """自动搜索训练产出的 best.pt。

    搜索顺序：
      1) runs/detect/*/weights/best.pt（含 train、train2 等所有实验目录）
      2) 兜底：项目内任意层级的 best.pt
    命中多个时按文件修改时间取【最新】的那个，
    这样无需记住实验目录名就能用上最近一次训练的成果。

    找不到时返回空 Path，由调用方给出中文提示。
    """
    candidates = list(RUNS_DETECT.glob("*/weights/best.pt"))
    if not candidates:
        candidates = list(PROJECT_ROOT.glob("**/best.pt"))
    if not candidates:
        return Path("")
    candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0]


def resolve_weights(arg_weights: str) -> Path:
    """确定最终使用的权重文件，并在缺失时给出明确的中文排错指引。"""
    if arg_weights:
        w = Path(arg_weights)
        # 相对路径按项目根目录解析，避免受当前工作目录影响
        if not w.is_absolute():
            w = (PROJECT_ROOT / w).resolve()
        if not w.is_file():
            print(f"[X] 找不到权重文件: {w}")
            print("    请先运行 python train.py 训练模型，或用 --weights 指定正确路径。")
            sys.exit(1)
        return w

    found = find_best_weights()
    if not found or not found.is_file():
        print("[X] 未在 runs/detect/*/weights/ 下找到 best.pt。")
        print("    本脚本要求使用【你自己训练得到的】权重，而非官方预训练权重。")
        print("    请先执行: python train.py")
        print("    （若尚未成功训练，可参考 results/README_results.md 与 report.md 的说明）")
        sys.exit(1)
    print(f"[i] 自动找到权重: {found}")
    return found


def pick_font(size: int):
    """挑选一个可用字体。

    返回 (font, ok)：
        ok=True  -> font 为 PIL FreeTypeFont，可渲染中文
        ok=False -> font 为 None，调用方应回退到英文标签
    该项纯属显示优化，失败不影响任何检测逻辑。
    """
    # 允许通过环境变量强制关闭中文字体（用于排查字体相关异常）
    if os.environ.get("YOLO_NO_ZH_FONT") == "1":
        return None, False
    try:
        from PIL import ImageFont
        for path in FONT_CANDIDATES:
            if os.path.isfile(path):
                try:
                    return ImageFont.truetype(path, size), True
                except Exception:
                    continue
    except Exception:
        pass
    return None, False


def draw_boxes_pil(image, boxes, names, line_width: int = 2, use_zh: bool = True):
    """用 PIL 在图片上绘制检测框 + 类别名 + 置信度（支持中文）。

    参数:
        image : PIL.Image（RGB）
        boxes : list[(x1, y1, x2, y2, conf, cls_id)]
        names : {class_id: class_name}，直接取自模型，保证与训练时编号一致
    返回:
        绘制完成的 PIL.Image
    """
    from PIL import ImageDraw

    img = image.copy()
    draw = ImageDraw.Draw(img)
    font, zh_ok = pick_font(16)
    use_pil_text = bool(zh_ok and use_zh)

    for (x1, y1, x2, y2, conf, cls_id) in boxes:
        cid = int(cls_id)
        color = PALETTE.get(cid, (0, 255, 0))

        # ---- 1) 画检测框（用多圈偏移模拟线宽，避免依赖 PIL 版本差异）----
        for k in range(line_width):
            draw.rectangle([x1 - k, y1 - k, x2 + k, y2 + k], outline=color)

        # ---- 2) 组织标签文本：类别名 + 置信度 ----
        en_name = str(names.get(cid, f"class{cid}"))
        if use_zh and en_name in CLASS_ZH:
            label = f"{CLASS_ZH[en_name]} {conf:.2f}"   # 例: 可乐 0.87
        else:
            label = f"{en_name} {conf:.2f}"             # 例: cola 0.87

        # ---- 3) 绘制标签底色与文字 ----
        if use_pil_text:
            # 有中文字体：用 PIL 绘制，标签放在框左上角外侧
            try:
                tb = draw.textbbox((0, 0), label, font=font)
                tw, th = tb[2] - tb[0], tb[3] - tb[1]
            except Exception:
                tw, th = 8 * len(label), 16
            ty = y1 - th - 4
            if ty < 0:                # 框贴到图片顶边时改画到框内，避免超出画布
                ty = y1 + 2
            draw.rectangle([x1, ty, x1 + tw + 6, ty + th + 4], fill=color)
            # 标签文字用黑色，保证在任何底色上都清晰可读
            draw.text((x1 + 3, ty + 2), label, fill=(0, 0, 0), font=font)
        else:
            # 无中文字体：回退到 OpenCV 绘制英文（不需要字体文件，必然可用）
            import cv2
            import numpy as np
            from PIL import Image

            arr = np.array(img)[:, :, ::-1].copy()   # PIL RGB -> OpenCV BGR
            (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            ty = y1 - th - 6
            if ty < 0:
                ty = y1 + 2
            cv2.rectangle(arr, (x1, ty), (x1 + tw + 4, ty + th + 6), color, -1)
            cv2.putText(arr, label, (x1 + 2, ty + th + 1),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            img = Image.fromarray(arr[:, :, ::-1])   # BGR -> PIL RGB

    return img


def collect_sources(source: str) -> list[Path]:
    """把 --source 归一化为图片文件列表（支持单文件 / 目录 / URL）。"""
    s = str(source)
    if s.startswith(("http://", "https://")):
        return []                       # URL 交给 Ultralytics 自行下载处理
    p = Path(s)
    if p.is_dir():
        # 目录则递归查找所有图片
        return sorted(q for q in p.rglob("*") if q.suffix.lower() in IMAGE_EXTS)
    return [p]


def main() -> None:
    args = parse_args()
    os.chdir(PROJECT_ROOT)     # 统一工作目录，保证相对路径含义稳定

    # =======================================================================
    # 1. 确定并加载权重
    # =======================================================================
    weights = resolve_weights(args.weights)
    print(f"[1/4] 加载模型权重: {weights}")

    try:
        from ultralytics import YOLO
    except ImportError:
        print("[X] 未安装 ultralytics，请先执行: pip install -r requirements.txt")
        sys.exit(1)

    model = YOLO(str(weights))
    # model.names 来自权重文件本身（形如 {0:'obstacle',1:'cola',2:'football'}），
    # 直接使用而不自行写死，可保证"画出的类别名"与"训练时的编号"绝对一致。
    print(f"[i] 模型类别表: {model.names}")

    # =======================================================================
    # 2. 检查输入
    # =======================================================================
    src_path = Path(str(args.source))
    sources = collect_sources(args.source)
    if not str(args.source).startswith(("http://", "https://")):
        if src_path.is_dir():
            if not sources:
                print(f"[X] 目录中未找到任何图片: {src_path}")
                sys.exit(1)
            print(f"[2/4] 输入为目录，共 {len(sources)} 张图片")
        elif not src_path.is_file():
            print(f"[X] 找不到输入图片: {src_path}")
            sys.exit(1)
        else:
            print(f"[2/4] 输入为单张图片: {src_path}")
    else:
        print(f"[2/4] 输入为网络图片: {args.source}")

    # =======================================================================
    # 3. 推理
    # =======================================================================
    print(f"[3/4] 开始推理（conf={args.conf}, iou={args.iou}, imgsz={args.imgsz}）...")
    results = model.predict(
        source=args.source,
        conf=args.conf,        # 置信度阈值
        iou=args.iou,          # NMS 的 IoU 阈值
        imgsz=args.imgsz,      # 输入尺寸
        device=args.device or None,
        save=True,             # 保存画框结果图
        save_txt=args.save_txt,      # 可选：保存 YOLO 格式 txt
        save_conf=args.save_conf,    # 可选：txt 附带置信度
        project=args.project,
        name=args.name,
        exist_ok=args.exist_ok,
        line_width=args.line_width,
        show_labels=True,      # 显示类别名
        show_conf=True,        # 显示置信度
        verbose=False,
    )

    # =======================================================================
    # 4. 用 PIL 重绘（中文标签）并打印检测摘要
    # =======================================================================
    print("[4/4] 绘制检测结果 ...")
    save_dir = Path(results[0].save_dir) if results else (RUNS_DETECT / args.name)
    total_boxes = 0

    for r in results:
        src_file = Path(r.path)
        xyxy = r.boxes.xyxy.cpu().numpy()    # 每个框的左上/右下坐标 (x1,y1,x2,y2)
        confs = r.boxes.conf.cpu().numpy()   # 每个框的置信度
        clses = r.boxes.cls.cpu().numpy()    # 每个框的类别 id
        total_boxes += len(xyxy)

        # ---- 4a. 用 PIL 重绘以支持中文标签，并覆盖 Ultralytics 保存的结果图 ----
        try:
            from PIL import Image

            with Image.open(src_file) as im:
                pil_img = im.convert("RGB")
                packed = [
                    (float(a), float(b), float(c), float(d), float(e), float(f))
                    for (a, b, c, d), e, f in zip(xyxy, confs, clses)
                ]
                drawn = draw_boxes_pil(pil_img, packed, r.names,
                                       line_width=args.line_width,
                                       use_zh=not args.no_zh)
                out_file = save_dir / src_file.name
                drawn.save(out_file)
                print(f"      已保存: {out_file}")
        except Exception as e:
            # 中文重绘属于显示优化，失败则保留 Ultralytics 的英文版本，不影响检测结果
            print(f"      [!] 中文标签绘制失败（{e!r}），保留原始结果图。")

        # ---- 4b. 打印每个框的类别与置信度（验收要求展示这两项）----
        if args.print_dets:
            if len(xyxy) == 0:
                print(f"      {src_file.name}: 未检测到目标（可尝试调低 --conf）")
            for (x1, y1, x2, y2), c, k in zip(xyxy, confs, clses):
                name = r.names.get(int(k), f"class{int(k)}")
                print(f"      {src_file.name} | 类别={name}(id={int(k)}) "
                      f"置信度={float(c):.3f} 框=({x1:.0f},{y1:.0f})-({x2:.0f},{y2:.0f})")

    print(f"\n[done] 共 {len(results)} 张图片、{total_boxes} 个检测框")
    print(f"       结果目录: {save_dir}")


if __name__ == "__main__":
    main()
