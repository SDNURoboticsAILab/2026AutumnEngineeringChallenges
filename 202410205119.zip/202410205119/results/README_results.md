# 训练完成后 results/ 目录应该存放什么

> **说明（重要）**
> 本目录是**说明性文档目录**，不是训练输出目录。
> 本项目在开发机（Windows 11）上**未能完整执行训练**（原因见 `../report.md` 第四节），
> 因此这里**没有任何真实的训练产物**：不放损失曲线图片、不放混淆矩阵图片、
> 不放推理效果图、不放权重文件。**所有内容均为"预期结果说明 + 样例日志"，不是真实训练产物。**
>
> 真实训练产物由 Ultralytics 自动写入 `../runs/detect/<实验名>/`。
> 待你在 Colab / Linux 上跑通训练后，按本文档的清单把结果整理到本目录并补齐截图。

---

## 1. 目录定位

| 目录 | 性质 | 内容 |
|---|---|---|
| `dataset/` | 输入（人工制作） | 图片 + 标注，人工维护 |
| `runs/` | 输出（程序自动生成） | Ultralytics 训练/推理自动写入，**初始为空** |
| `results/` | 结果整理（人工/半自动） | 本文档 + 训练完成后从 `runs/` 挑选整理出的展示材料 |

设计意图是把"程序自动产物"与"提交用展示材料"分开：
`runs/` 保持原样不动，`results/` 用来交付与阅读。

---

## 2. 训练完成后，`runs/detect/train/` 会自动生成这些文件

下表为 Ultralytics YOLOv8 训练结束后的标准输出（文件名固定，由框架生成）：

| 文件 / 目录 | 内容 | 用途 |
|---|---|---|
| `weights/best.pt` | 验证集指标最好的那一轮权重 | ★ `predict.py` 默认加载它做推理 |
| `weights/last.pt` | 最后一轮权重 | 断点续训（`--resume`） |
| `args.yaml` | 本次训练使用的全部超参 | 实验记录，复现实验靠它 |
| `results.csv` | 每轮的 loss / precision / recall / mAP 数值 | 做表格、画图、写报告的原始数据 |
| `results.png` | loss 与各项指标随 epoch 变化的曲线 | ★ 训练过程证据截图 |
| `confusion_matrix.png` | 混淆矩阵（真实类别 × 预测类别） | ★ 分析类别混淆情况 |
| `confusion_matrix_normalized.png` | 按行归一化的混淆矩阵 | 看每类的召回率分布 |
| `BoxP_curve.png` | Precision-Confidence 曲线 | 观察阈值与精确率关系 |
| `BoxR_curve.png` | Recall-Confidence 曲线 | 观察阈值与召回率关系 |
| `BoxPR_curve.png` | Precision-Recall 曲线（曲线下面积即 AP） | 看单类检测质量 |
| `BoxF1_curve.png` | F1-Confidence 曲线 | 找 F1 最大的置信度阈值 |
| `train_batch0/1/2.jpg` | 训练时送入网络的批次可视化（含增强后的框） | 确认增强合理、标签位置正确 |
| `val_batch0_labels.jpg` | 验证集**真实标签**可视化 | 与下一张对比 |
| `val_batch0_pred.jpg` | 验证集**预测结果**可视化 | ★ 最直观的效果证据 |
| `labels.jpg` | 数据集中目标框的分布统计 | 检查数据分布是否合理 |
| `labels_correlogram.jpg` | 框中心点/宽高相关性图 | 检查标注是否异常 |

> 首次训练输出到 `runs/detect/train/`；再次运行会依次生成
> `train2/`、`train3/`……除非在 `train.py` 中指定 `--exist-ok`。

---

## 3. 建议整理进本目录的展示材料

训练成功后，建议从 `runs/detect/train/` 挑出下列文件复制到本目录
（或在本目录建立 `figures/` 子目录统一存放），命名建议如下：

```text
results/
├── README_results.md            # 本文件：目录说明
├── training_log_sample.md       # 模拟训练输出日志样例（文档，非真实产物）
├── inference_sample.md          # 推理结果样例（文档，非真实产物）
├── image_filelist.md            # 6 张图片的文件名清单与标注说明
└── figures/                     # ← 训练完成后自行放入，当前为空
    ├── 01_results.png           # 复制自 runs/detect/train/results.png
    ├── 02_confusion_matrix.png  # 复制自 runs/detect/train/confusion_matrix.png
    ├── 03_val_labels.jpg        # 复制自 runs/detect/train/val_batch0_labels.jpg
    ├── 04_val_pred.jpg          # 复制自 runs/detect/train/val_batch0_pred.jpg
    ├── 05_train_batch0.jpg      # 复制自 runs/detect/train/train_batch0.jpg
    ├── 06_pr_curve.png          # 复制自 runs/detect/train/BoxPR_curve.png
    ├── 07_predict_single.jpg    # 复制自 runs/detect/predict/（单目标结果图）
    ├── 08_predict_multi.jpg     # 复制自 runs/detect/predict/（多目标结果图）
    ├── 09_predict_other.jpg     # 复制自 runs/detect/predict/（不同角度结果图）
    └── 10_gradio_demo.png       # Level 5 网页演示运行截图
```

### 每类材料的用途

- **损失曲线（results.png）**：证明训练确实在收敛。
  正常表现是 `box_loss / cls_loss / dfl_loss` 三条训练曲线整体下降并逐步趋于平缓。
- **混淆矩阵（confusion_matrix.png）**：证明各类别是否被区分开。
  对角线越深越好；若 `cola` 与 `football` 互相混淆，说明这两类特征区分度不足，
  在 6 张图的规模下属正常现象。
- **验证集对比图（val_batch0_labels.jpg / val_batch0_pred.jpg）**：
  前者的框是标注真值，后者是模型预测，两者越接近说明效果越好。
  这是最直观、最容易被认可的"效果证据"。
- **推理效果图（predict 结果）**：应由 `predict.py` 对**训练集之外**的新图片生成，
  图上须同时可见目标框、类别名称、置信度三项，对应 Level 4 的验收要求。

---

## 4. 诚实声明（关于本目录当前内容）

| 项目 | 当前状态 |
|---|---|
| 真实训练权重（`best.pt`） | ❌ 不存在，未训练成功，不伪造 |
| 真实训练日志 / 结果曲线 | ❌ 不存在，不伪造 |
| 真实推理效果图 | ❌ 不存在，不伪造 |
| 模拟训练日志（文档形式） | ✅ 见 `training_log_sample.md`，已明确标注为"样例/预期" |
| 模拟推理输出（文档形式） | ✅ 见 `inference_sample.md`，已明确标注为"样例/预期" |
| 数据标注文件 | ✅ 真实存在，`../dataset/labels/` 下 6 个 txt |
| `data.yaml` 与代码 | ✅ 真实存在，且已通过 Ultralytics 解析校验 |

**为什么不放"看起来像真的"的结果图：**
伪造的曲线图和效果图无法反映真实训练状态，会误导评阅与后续复现。
本项目的做法是**如实说明未完成原因（长路径策略限制）+ 给出完整可复现流程**，
让任何人能按 `../report.md` 第九节在 Colab 上跑出真实结果。

---

## 5. 快速核对清单（训练完成后）

- [ ] `runs/detect/train/weights/best.pt` 存在
- [ ] `runs/detect/train/results.csv` 中 `metrics/mAP50(B)` 出现非 0 数值
- [ ] `results.png` 中三条 loss 曲线整体下降
- [ ] 已把训练结果图复制到 `results/figures/`
- [ ] 已用 `predict.py` 对训练集外的新图片推理，并保存结果图
- [ ] 结果图上可同时看到 目标框 / 类别名称 / 置信度
- [ ] 已启动 `gradio_demo` 类网页演示并截图（若完成 Level 5）
