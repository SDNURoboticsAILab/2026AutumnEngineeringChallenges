# 模拟训练输出日志样例（预期结果，非真实产物）

> # ⚠️ 重要声明
> **本文档中的日志是"如果环境正常运行，`train.py` 会输出什么样"的样例/预期说明，
> 不是本项目真实跑出来的训练日志。**
>
> 生成方式说明：
> - **日志的格式**依据 Ultralytics 8.x `DetectionTrainer` 的实际输出格式编写
>   （表头字段、进度条列名、`Class`/`all` 汇总行结构、`Results saved to ...` 结尾均按真实格式）；
> - **其中的 loss 与 mAP 数值属于示意值**，仅用于说明"正常收敛时数值应如何变化"，
>   **不代表本项目已获得该指标**；
> - 本项目开发机因系统长路径策略限制未能完整执行训练，详见 `../report.md` 第四节；
> - 真实产物只会出现在 `../runs/detect/<实验名>/`，且本仓库中 `runs/` 保持为空。
>
> 真实运行方式见 `../report.md` 第九节（Colab 复现指南）。

---

## 样例一：GPU 环境完整训练（建议的正式训练配置）

对应命令（在项目根目录执行）：

```bash
python train.py --epochs 100 --imgsz 640 --batch 4 --device 0
```

### 1. 启动阶段输出

```text
==========================================================================
 训练前自检 (pre-flight check)
==========================================================================
[OK] ultralytics 版本 : 8.4.163
[OK] torch 版本       : 2.4.1+cu121
[OK] CUDA 可用        : True
[OK] data.yaml        : /content/2026XXXXXX/data.yaml
[OK] nc               : 3
[OK] names            : {0: 'obstacle', 1: 'cola', 2: 'football'}
[OK] train 图片目录 : /content/2026XXXXXX/dataset/images/train  （4 张）
[OK] val   图片目录 : /content/2026XXXXXX/dataset/images/val  （2 张）
[OK] 有效的 图片/标签 配对数量: 6
==========================================================================
[1/3] 加载模型: yolov8n.pt
[2/3] 开始训练: epochs=100, imgsz=640, batch=4
Ultralytics 8.4.163 🚀 Python-3.12.10 torch-2.4.1+cu121 CUDA:0 (Tesla T4, 15102MiB)
```

> 说明：`CUDA:0 (Tesla T4, 15102MiB)` 表示检测到 GPU 并已启用；
> 若本机无 GPU，这一行会显示 `CPU`，训练速度会慢一到两个数量级。

### 2. 训练配置与数据扫描

```text
overrides: task=detect, mode=train, model=yolov8n.pt, data=/content/2026XXXXXX/data.yaml,
  epochs=100, patience=50, batch=4, imgsz=640, save=True, cache=True, device=0,
  workers=8, optimizer=auto, lr0=0.01, lrf=0.01, momentum=0.937, weight_decay=0.0005,
  warmup_epochs=3.0, hsv_h=0.015, hsv_s=0.7, hsv_v=0.4, degrees=0.0, translate=0.1,
  scale=0.5, fliplr=0.5, flipud=0.0, mosaic=1.0, close_mosaic=10, seed=42, val=True,
  plots=True
WARNING ⚠️ 'deterministic=True' may cause small numerical differences between runs.
train: Scanning /content/2026XXXXXX/dataset/labels/train... 4 images, 0 backgrounds, 0 corrupt: 100%|██████████| 4/4
train: New cache created: /content/2026XXXXXX/dataset/labels/train.cache
val: Scanning /content/2026XXXXXX/dataset/labels/val... 2 images, 0 backgrounds, 0 corrupt: 100%|██████████| 2/2
val: New cache created: /content/2026XXXXXX/dataset/labels/val.cache
Plotting labels to runs/detect/train/labels.jpg...
optimizer: 'optimizer=auto' found, ignoring 'lr0=0.01' and 'momentum=0.937' and determining best 'optimizer' from 'iterations=100'
optimizer: AdamW(lr=0.002, momentum=0.9) with parameter groups 48 weight(decay=0.0), 57 weight(decay=0.0005), 56 bias(decay=0.0)
```

> 判读要点：
> - `4 images, 0 backgrounds, 0 corrupt` —— **这一行是标注是否有效的最好证明**。
>   若标签为空或坐标未归一化，`corrupt` 数会不为 0，或图片被算成 `backgrounds`。
> - `0 backgrounds` 说明每张图都至少有一个有效目标框，与 `dataset/labels/` 内容一致。

### 3. 训练过程（每轮一行，节选）

```text
Image sizes 640 train, 640 val
Using 8 dataloader workers
Logging results to runs/detect/train
Starting training for 100 epochs...

      Epoch    GPU_mem   box_loss   cls_loss   dfl_loss  Instances       Size
        1/100     1.87G      1.4821     3.9241      1.5310          8        640: 100%|██████████| 1/1
                 Class     Images  Instances      Box(P          R      mAP50  mAP50-95): 100%|██████████| 1/1
                   all          2          4      0.412      0.333      0.281     0.104

      Epoch    GPU_mem   box_loss   cls_loss   dfl_loss  Instances       Size
       10/100     1.91G      1.1204     2.4187      1.2743          8        640: 100%|██████████| 1/1
                 Class     Images  Instances      Box(P          R      mAP50  mAP50-95): 100%|██████████| 1/1
                   all          2          4      0.688      0.556      0.593     0.281

      Epoch    GPU_mem   box_loss   cls_loss   dfl_loss  Instances       Size
       30/100     1.89G      0.8213     1.3965      1.0521          8        640: 100%|██████████| 1/1
                 Class     Images  Instances      Box(P          R      mAP50  mAP50-95): 100%|██████████| 1/1
                   all          2          4      0.842      0.750      0.812     0.472

      Epoch    GPU_mem   box_loss   cls_loss   dfl_loss  Instances       Size
       60/100     1.90G      0.5108     0.8621      0.8341          8        640: 100%|██████████| 1/1
                 Class     Images  Instances      Box(P          R      mAP50  mAP50-95): 100%|██████████| 1/1
                   all          2          4      0.915      0.833      0.894     0.604

      Epoch    GPU_mem   box_loss   cls_loss   dfl_loss  Instances       Size
       90/100     1.88G      0.3012     0.5184      0.6902          8        640: 100%|██████████| 1/1
                 Class     Images  Instances      Box(P          R      mAP50  mAP50-95): 100%|██████████| 1/1
                   all          2          4      0.968      0.917      0.952     0.741

      Epoch    GPU_mem   box_loss   cls_loss   dfl_loss  Instances       Size
      100/100     1.90G      0.2143     0.4031      0.6214          8        640: 100%|██████████| 1/1
                 Class     Images  Instances      Box(P          R      mAP50  mAP50-95): 100%|██████████| 1/1
                   all          2          4      0.976      0.950      0.968     0.792
```

### 4. 逐类指标与结束输出

```text
                 Class     Images  Instances      Box(P          R      mAP50  mAP50-95): 100%|██████████| 1/1
                   all          2          4      0.976      0.950      0.968     0.792
              obstacle          1          1      1.000      1.000      0.995     0.861
                  cola          2          2      0.964      0.900      0.955     0.780
              football          2          1      0.964      0.950      0.955     0.735

100 epochs completed in 0.021 hours.
Optimizer stripped from runs/detect/train/weights/last.pt, 6.2MB
Optimizer stripped from runs/detect/train/weights/best.pt, 6.2MB

Validating runs/detect/train/weights/best.pt...
Ultralytics 8.4.163 🚀 Python-3.12.10 torch-2.4.1+cu121 CUDA:0 (Tesla T4, 15102MiB)
                 Class     Images  Instances      Box(P          R      mAP50  mAP50-95): 100%|██████████| 1/1
                   all          2          4      0.981      0.967      0.972     0.798
Speed: 0.4ms preprocess, 3.1ms inference, 0.0ms loss, 0.6ms postprocess per image

Results saved to runs/detect/train
[3/3] 训练结束，输出目录: /content/2026XXXXXX/runs/detect/train
      最佳权重: /content/2026XXXXXX/runs/detect/train/weights/best.pt  （存在: True）
```

---

## 样例二：CPU 环境短程训练（本项目开发机的真实限制场景）

对应命令（本机可行的小规模配置，用于验证流程）：

```bash
python train.py --epochs 30 --imgsz 320 --batch 2 --device cpu
```

```text
==========================================================================
 训练前自检 (pre-flight check)
==========================================================================
[OK] ultralytics 版本 : 8.4.163
[OK] torch 版本       : 2.10.0+cpu
[OK] CUDA 可用        : False
     [!] 未检测到可用 GPU，将回退到 CPU 训练。
         建议先用小规模跑通流程: --epochs 30 --imgsz 320 --batch 2
         正式训练建议放到 Colab / Linux 的 GPU 环境（见 README 复现指南）。
[OK] data.yaml        : C:\Users\zhonglilsq\Desktop\论文\2026XXXXXX\data.yaml
[OK] nc               : 3
[OK] names            : {0: 'obstacle', 1: 'cola', 2: 'football'}
[OK] train 图片目录 : C:\Users\zhonglilsq\Desktop\论文\2026XXXXXX\dataset\images\train  （4 张）
[OK] val   图片目录 : C:\Users\zhonglilsq\Desktop\论文\2026XXXXXX\dataset\images\val  （2 张）
[OK] 有效的 图片/标签 配对数量: 6
==========================================================================
[1/3] 加载模型: yolov8n.pt
[2/3] 开始训练: epochs=30, imgsz=320, batch=2

Ultralytics 8.4.163 🚀 Python-3.12.10 torch-2.10.0+cpu CPU (AMD64 Family 25 Model 117)
overrides: task=detect, mode=train, model=yolov8n.pt, data=.../data.yaml, epochs=30,
  batch=2, imgsz=320, device=cpu, workers=0, cache=True, seed=42

train: Scanning .../dataset/labels/train... 4 images, 0 backgrounds, 0 corrupt: 100%|██████████| 4/4
val: Scanning .../dataset/labels/val... 2 images, 0 backgrounds, 0 corrupt: 100%|██████████| 2/2

      Epoch    GPU_mem   box_loss   cls_loss   dfl_loss  Instances       Size
        1/30        0G      1.6013     4.1027      1.5842          4        320: 100%|██████████| 2/2
                 Class     Images  Instances      Box(P          R      mAP50  mAP50-95): 100%|██████████| 1/1
                   all          2          4      0.201      0.250      0.112     0.031
```

> **本机实际卡在哪一步：**
> 上面这段"启动 + 扫描数据集 + 首轮前向"在 CPU 上是可以走通的，
> 但完整 30~100 轮训练耗时过长；更关键的是本项目所在路径
> （`C:\Users\zhonglilsq\Desktop\论文\...`）触发了 Windows 长路径策略问题，
> 训练过程中生成深层输出文件时报路径相关异常而中断。
> 详见 `../report.md` 第四节"Windows 长路径问题"。

---

## 5. 预期 loss 变化规律（判读依据）

| 阶段 | box_loss | cls_loss | dfl_loss | 验证 mAP50 | 说明 |
|---|---|---|---|---|---|
| 第 1~5 轮 | 快速下降 | 快速下降 | 缓慢下降 | 很低（0.1 以下） | 热身阶段，正在适应新类别头 |
| 第 10~30 轮 | 稳步下降 | 稳步下降 | 稳步下降 | 明显上升 | 主要学习阶段 |
| 第 50~80 轮 | 缓慢下降 | 缓慢下降 | 趋于平缓 | 缓慢上升或小幅波动 | 接近收敛 |
| 第 90~100 轮 | 基本平稳 | 基本平稳 | 基本平稳 | 趋于稳定 | 已收敛；`close_mosaic` 生效后可能小幅跳变 |
| 异常情况 | 不降 / 上升 | 不降 / 为 0 | 不降 | 恒为 0 | 多为标注错误：坐标未归一化、类别号越界、图标签不同名 |

### 关于"loss 降但 mAP 不涨"

这是**小数据集过拟合**的典型表现：模型把 4 张训练图记住了，
但学到的是"这几张图的具体样子"而非"可乐/足球的普遍特征"，
因此换到 val 的 2 张图（不同摆放与角度）上表现上不去。

本项目只有 6 张图，出现这种情况属于预期之内，不是代码错误。
缓解手段（按有效性排序）：

1. **扩充数据量**（最有效，几百张起）——`data.yaml` 与代码无需任何修改；
2. 依赖 `train.py` 中已开启的数据增强（`mosaic=1.0`、`fliplr=0.5`、HSV 抖动、缩放平移）；
3. 调小学习率（`--lr0 0.001`）避免破坏预训练权重；
4. 增大 `--weight-decay` 加强正则。

### 关于指标水平的现实预期

`val` 集只有 **2 张图、4 个目标框**，指标统计意义很弱
（漏检 1 个框，mAP 就会掉很大一截）。
因此：

- **可以**用它确认训练流程跑通、模型确实学到了东西（mAP50 明显大于 0）；
- **不可以**用它宣称模型精度达到某个水平，也不宜与其他项目横向比较。

---

## 6. 与本文档对应的真实文件（训练后应出现）

```text
runs/detect/train/
├── weights/
│   ├── best.pt      ← 6.2MB 左右（YOLOv8-n）
│   └── last.pt
├── args.yaml
├── results.csv
├── results.png
├── confusion_matrix.png
├── confusion_matrix_normalized.png
├── BoxF1_curve.png
├── BoxP_curve.png
├── BoxPR_curve.png
├── BoxR_curve.png
├── labels.jpg
├── labels_correlogram.jpg
├── train_batch0.jpg
├── train_batch1.jpg
├── train_batch2.jpg
├── val_batch0_labels.jpg
├── val_batch0_pred.jpg
├── val_batch1_labels.jpg
└── val_batch1_pred.jpg
```

查看 `results.csv` 的推荐方式：

```python
import pandas as pd
df = pd.read_csv("runs/detect/train/results.csv")
df.columns = [c.strip() for c in df.columns]   # 列名可能带前导空格
print(df[["epoch", "train/box_loss", "train/cls_loss",
          "metrics/precision(B)", "metrics/recall(B)", "metrics/mAP50(B)"]].tail(10))
```
