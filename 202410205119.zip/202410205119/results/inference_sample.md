# 推理结果样例（预期结果，非真实产物）

> # ⚠️ 重要声明
> **本文档描述"训练成功后，用 `predict.py` 检测新图片会输出什么"，属于预期说明与格式样例，
> 不是本项目真实产生的推理结果。**
>
> 实际情况说明：
> - 本项目开发机**没有可用的 `best.pt`**（未完成训练），因此**无法产生真实推理结果**；
> - 开发机同时**无外网访问**，连官方预训练权重 `yolov8n.pt` 都无法下载，
>   因此也无法用一个临时模型来"演示"输出；
> - 本文档中**终端输出的格式**依据 Ultralytics `Results` 对象的实际接口编写
>   （`r.boxes.xyxy` / `r.boxes.conf` / `r.boxes.cls` / `r.names` 与 `predict.py` 的打印逻辑一致），
>   **其中的类别名与置信度数值为示意值**；
> - 本仓库中 `runs/` 保持为空，**不包含任何伪造的结果图或权重**。
>
> 真实运行方式：训练成功后执行 `python predict.py --source <图片或目录>`，
> 结果图写入 `../runs/detect/predict/`。见 `../report.md` 第九节。

---

## 1. 预期终端输出格式

对应命令：

```bash
python predict.py --weights runs/detect/train/weights/best.pt --source new_photos --print-dets
```

预期输出（结构为 `predict.py` 的实际打印逻辑，数值为示意）：

```text
[1/4] 加载模型权重: /content/2026XXXXXX/runs/detect/train/weights/best.pt
[i] 模型类别表: {0: 'obstacle', 1: 'cola', 2: 'football'}
[2/4] 输入为目录，共 4 张图片
[3/4] 开始推理（conf=0.25, iou=0.45, imgsz=640）...

image 1/4 /content/2026XXXXXX/new_photos/test_scene.jpg: 480x640 1 obstacle, 1 cola, 1 football, 12.3ms
image 2/4 /content/2026XXXXXX/new_photos/test_cola.jpg: 480x640 1 cola, 11.8ms
image 3/4 /content/2026XXXXXX/new_photos/test_multi.jpg: 480x640 2 cola, 1 football, 13.1ms
image 4/4 /content/2026XXXXXX/new_photos/test_angle.jpg: 480x640 1 obstacle, 1 football, 12.6ms
Speed: 0.3ms preprocess, 12.3ms inference, 0.0ms loss, 0.8ms postprocess per image
Results saved to /content/2026XXXXXX/runs/detect/predict

[4/4] 绘制检测结果 ...
      已保存: /content/2026XXXXXX/runs/detect/predict/test_scene.jpg
      已保存: /content/2026XXXXXX/runs/detect/predict/test_cola.jpg
      已保存: /content/2026XXXXXX/runs/detect/predict/test_multi.jpg
      已保存: /content/2026XXXXXX/runs/detect/predict/test_angle.jpg
      test_scene.jpg | 类别=obstacle(id=0) 置信度=0.891 框=(392,118)-(612,456)
      test_scene.jpg | 类别=cola(id=1) 置信度=0.874 框=(150,200)-(292,420)
      test_scene.jpg | 类别=football(id=2) 置信度=0.836 框=(92,252)-(222,382)
      test_cola.jpg | 类别=cola(id=1) 置信度=0.912 框=(215,145)-(365,375)
      test_multi.jpg | 类别=cola(id=1) 置信度=0.868 框=(120,180)-(262,392)
      test_multi.jpg | 类别=cola(id=1) 置信度=0.641 框=(330,210)-(452,386)
      test_multi.jpg | 类别=football(id=2) 置信度=0.793 框=(470,240)-(600,370)
      test_angle.jpg | 类别=obstacle(id=0) 置信度=0.815 框=(240,190)-(452,420)
      test_angle.jpg | 类别=football(id=2) 置信度=0.702 框=(60,300)-(190,430)

[done] 共 4 张图片、9 个检测框
       结果目录: /content/2026XXXXXX/runs/detect/predict
```

### 两类速度指标的解读

| 指标 | 预期量级 | 说明 |
|---|---|---|
| `inference`（推理耗时） | CPU 约 60~200 ms/张；GPU(T4) 约 3~13 ms/张 | 单张 640×480 图片 |
| `preprocess` / `postprocess` | 各 0.3~1 ms | 缩放归一化 / NMS 后处理 |

> 结论：**推理在 CPU 上完全可用**（一张图不到一秒），
> 因此"训练放 Colab GPU、推理与网页演示放本机 CPU"是可行且常见的组合。

---

## 2. 预期推理效果图应呈现的内容

`predict.py` 绘制的结果图，每个目标应有以下三要素（对应 Level 4 验收要求）：

```text
┌─────────────────────────────────────────────────────────┐
│                                                         │
│   ┌──────────────┐                                      │
│   │ 障碍物 0.89  │ ← ① 标签底色块 + ② 类别名称 + ③ 置信度 │
│   └──────────────┘                                      │
│   ┌────────────────────────────┐                        │
│   │                            │                        │
│   │        （目标本体）         │ ← 目标边界框            │
│   │                            │                        │
│   └────────────────────────────┘                        │
│                                                         │
│        ┌──────────────┐                                 │
│        │ 可乐 0.87    │                                 │
│        └──────────────┘                                 │
│        ┌────────────┐                                   │
│        │            │                                   │
│        │  （目标）   │                                   │
│        └────────────┘                                   │
└─────────────────────────────────────────────────────────┘
```

### 具体绘制规则（`predict.py` 中的实现）

| 元素 | 规则 |
|---|---|
| 边界框 | 矩形框，线宽由 `--line-width` 控制（默认 2） |
| 类别颜色 | 固定配色：obstacle 番茄红 / cola 道奇蓝 / football 金色 |
| 标签文本 | `类别名 置信度`，置信度保留 2 位小数，如 `可乐 0.87` |
| 标签位置 | 画在框左上角外侧；若框贴到图片顶边，则改画到框内侧，避免被裁切 |
| 标签底色 | 与框同色实心块，文字用黑色，保证任何底色上都清晰 |
| 中文支持 | 优先用微软雅黑/黑体等中文字体渲染中文；找不到字体自动回退英文（`cola 0.87`） |

> 关于中文标签：OpenCV 的 `cv2.putText` 只支持 ASCII，直接写中文会变成一串问号，
> 所以 `predict.py` 用 PIL 的 `ImageFont` 来渲染中文，并在找不到字体时优雅回退到英文，
> 不会因为字体缺失而报错。

---

## 3. 三种应展示的检测场景（验收建议）

Level 4 要求至少覆盖以下几种情况，建议各准备一张结果图：

| # | 场景 | 目的 | 对应本项目图片 |
|---|---|---|---|
| ① | 单个目标 | 验证基础检测能力 | 类似 `img03.jpg`（仅可乐）/ `img04.jpg`（仅足球）的新图 |
| ② | 多个目标同框 | 验证多目标同时检出、不互相漏检 | 类似 `img01.jpg`（三类同框）的新图 |
| ③ | 不同场景 / 拍摄角度 | 验证泛化能力，而非记住训练图 | 类似 `img05/img06.jpg` 换个角度拍的新图 |

**重要**：第 ④ 项本质要求是"**训练集之外的新图片**"。
直接拿 `dataset/images/train/` 里的图去检测，得到的是训练集上的拟合效果，
不能作为泛化能力证据。请用新拍的图片。

---

## 4. 预期指标水平的现实评估

### 4.1 在训练集内的图片上

预期置信度较高（多在 0.80 以上），框位置也较准，
因为模型在训练中反复见过这几张图。**这不代表模型好用。**

### 4.2 在训练集外的新图片上

这是真正需要关心的场景。以 6 张图训练出的模型，现实预期是：

| 情形 | 预期表现 | 原因 |
|---|---|---|
| 与训练环境相似（同桌面、同光照、同角度） | 能检出主要目标，置信度 0.6~0.9 | 特征分布接近训练数据 |
| 换了背景 / 光照 | 明显退化，可能漏检或置信度骤降 | 训练集背景过于单一 |
| 换了同类但不同外观的目标（如另一品牌可乐） | 很可能检不到 | 模型只见过一种瓶型，学成了"这一瓶"而非"可乐" |
| 目标很小或被遮挡 | 容易漏检 | 训练集中小目标样本不足 |
| 三个类别同时出现 | 可能出现 1~2 个漏检 | 验证集仅 4 个框，多类共存样本太少 |

### 4.3 关于 mAP 数值的说明

`val` 集只有 **2 张图 / 4 个目标框**，因此：

- mAP50 能明显大于 0，就说明**训练流程是通的、模型确实学到了特征**；
- 但该数值**受单张图影响极大**（漏检 1 个框就可能让 mAP 掉 0.2 以上），
  **不具备统计意义**，不应作为"模型精度"来引用；
- 若出现 `mAP50 = 0` 或 `nan`，优先排查（按可能性排序）：
  1. 标签文件为空（本项目遇到过的 Make-Sense 导出 bug，见 `../report.md` 第三节）；
  2. 坐标未归一化（写成像素值，YOLO 会丢弃这些框）；
  3. 图片与标签文件名不一致（YOLO 按图片名找标签，名字对不上等于没有标签）；
  4. `data.yaml` 的 `nc` 与 `names` 数量不一致。

---

## 5. 快速自检：拿到结果图后怎么判断是否正常

- [ ] 图上是否同时出现 **目标框 + 类别名称 + 置信度** 三项
- [ ] 类别名称是否为 `obstacle / cola / football`（或其中文）
      —— 若出现 `person`、`bottle`、`car` 等 COCO 类别名，说明加载的是官方预训练权重
      而不是本项目训练的 `best.pt`
- [ ] 框的位置是否**贴合目标轮廓**（明显偏移说明标签坐标有问题）
- [ ] 置信度数值是否在 0~1 之间且相对合理（全部接近 0.25 说明只是刚好过阈值）
- [ ] 是否使用了**训练集之外**的图片

---

## 6. 复现真实推理的完整步骤（摘要）

```bash
# 0) 前提：已完成训练，存在 runs/detect/train/weights/best.pt

# 1) 准备训练集之外的新图片，例如放入 new_photos/
mkdir new_photos        # Windows: md new_photos

# 2) 推理（自动搜索 best.pt）
python predict.py --source new_photos --conf 0.25 --print-dets

# 3) 结果图位置
#    runs/detect/predict/<原文件名>.jpg
```

详细环境搭建与 Colab 复现步骤见 `../report.md` 第九节。
